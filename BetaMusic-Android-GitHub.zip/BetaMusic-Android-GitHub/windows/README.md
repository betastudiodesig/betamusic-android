# ẞetaMusic 1.1

Versión mejorada basada en el código fuente estable ẞetaMusic 1.0. Mantiene la base de IndexedDB y la reproducción local existente, y añade herramientas para descubrir y organizar la biblioteca.

## Novedades 1.1
- Selección de una carpeta de música desde Configuración. La aplicación importa los archivos de audio compatibles de esa carpeta a su biblioteca interna; los originales no se mueven ni se borran. La carpeta se importa de nuevo manualmente si más adelante se agregan canciones nuevas.
- Búsqueda local más inteligente, con prioridad por coincidencias de título y artista, búsqueda por álbum/género y tolerancia limitada a errores de escritura.
- Nueva sección «Para ti» con canciones y álbumes recomendados según reproducciones, favoritos, tiempo de escucha y actividad reciente. Estos cálculos se realizan localmente; no se envía el historial a un servidor.
- Botón «Letras» en el reproductor. Busca primero letras incrustadas en el archivo y después, si hace falta, consulta LRCLIB por Internet. Las letras sincronizadas se resaltan durante la reproducción cuando existen marcas de tiempo.

## Identidad
- Nombre visible: ẞetaMusic 1.1.
- Logotipo: variante Aurora (símbolo ẞ en azul y violeta).
- Icono de Windows: `icon.ico`, basado en Aurora.
- Pantalla de inicio: marca ẞetaMusic y lema «TU MÚSICA, SIN LÍMITES».

## Compatibilidad de datos
Se conserva la carpeta de datos de usuario `Auro Music` para que el perfil existente pueda seguir usando IndexedDB, preferencias y configuración de Google guardados previamente. Las claves internas y canales IPC heredados también se mantienen para evitar cambios innecesarios sobre funciones estables. No elimines la versión anterior ni su carpeta de datos hasta confirmar que la biblioteca, las playlists y los favoritos siguen presentes.

## Ejecutar desde el código
Requiere Node.js compatible con la versión de Electron incluida. En la carpeta del proyecto: `npm install` y después `npm start`. Para crear el instalador de Windows: `npm run build`.

## Comprobaciones
`npm run check` valida la sintaxis de los archivos JavaScript principales. No equivale a una prueba integral con la ventana Electron, la reproducción, la selección de carpetas y las solicitudes online. Para probar letras online se necesita conexión a Internet; la consulta usa la API pública de LRCLIB.
