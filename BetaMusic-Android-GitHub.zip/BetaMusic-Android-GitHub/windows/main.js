const { app, BrowserWindow, ipcMain, shell } = require('electron');
const https = require('https');
const http = require('http');
const path = require('path');
const fs = require('fs');
const os = require('os');
const crypto = require('crypto');

// Keep the existing data directory from Auro Music 4.6.1 so IndexedDB, preferences and OAuth config remain accessible after rebranding.
try { app.setPath('userData', path.join(app.getPath('appData'), 'Auro Music')); } catch (error) { console.warn('No se pudo conservar la carpeta de datos anterior:', error); }

function getGoogleAuthConfigPath() { return path.join(app.getPath('userData'), 'google-auth-config.json'); }
const GOOGLE_AUTH_TIMEOUT_MS = 180000;



function fetchJson(url) {
  return new Promise((resolve, reject) => {
    let parsed;
    try { parsed = new URL(url); } catch { reject(new Error('URL inválida')); return; }
    const client = parsed.protocol === 'https:' ? https : http;
    const request = client.get(parsed, { headers: { 'User-Agent': 'ẞetaMusic/1.1' } }, (response) => {
      let body = '';
      response.setEncoding('utf8');
      response.on('data', chunk => { body += chunk; });
      response.on('end', () => {
        if (response.statusCode < 200 || response.statusCode >= 300) {
          reject(new Error(`HTTP ${response.statusCode}`));
          return;
        }
        try { resolve(JSON.parse(body)); }
        catch { reject(new Error('Respuesta JSON inválida')); }
      });
    });
    request.setTimeout(15000, () => request.destroy(new Error('Tiempo de espera agotado')));
    request.on('error', reject);
  });
}

ipcMain.handle('auro-online-fetch-json', async (_event, url) => {
  const parsed = new URL(String(url));
  const allowedHosts = new Set(['api.jamendo.com', 'lrclib.net']);
  if (parsed.protocol !== 'https:' || !allowedHosts.has(parsed.hostname) || !parsed.pathname.startsWith('/api/')) throw new Error('Destino no permitido');
  return fetchJson(parsed.toString());
});


function readGoogleAuthConfig() {
  try {
    const config = JSON.parse(fs.readFileSync(getGoogleAuthConfigPath(), 'utf8'));
    const clientId = String(config.clientId || '').trim();
    const clientSecret = String(config.clientSecret || '').trim();
    const configured = Boolean(clientId && !/YOUR_|PEGA_AQUI|REEMPLAZA/i.test(clientId));
    return { configured, clientId: configured ? clientId : '', clientSecret };
  } catch {
    return { configured: false, clientId: '', clientSecret: '' };
  }
}

function postFormJson(url, values) {
  return new Promise((resolve, reject) => {
    let parsed;
    try { parsed = new URL(url); } catch { reject(new Error('URL OAuth no válida')); return; }
    if (parsed.protocol !== 'https:') { reject(new Error('El endpoint OAuth debe usar HTTPS')); return; }
    const body = new URLSearchParams(values).toString();
    const request = https.request(parsed, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Content-Length': Buffer.byteLength(body),
        'User-Agent': 'ẞetaMusic/1.1',
      },
    }, (response) => {
      let raw = '';
      response.setEncoding('utf8');
      response.on('data', chunk => { raw += chunk; });
      response.on('end', () => {
        let data;
        try { data = JSON.parse(raw); } catch { reject(new Error('Respuesta OAuth JSON no válida')); return; }
        if (response.statusCode < 200 || response.statusCode >= 300) {
          const detail = data.error_description || data.error || `HTTP ${response.statusCode}`;
          reject(new Error(`Google no pudo completar la autenticación: ${detail}`));
          return;
        }
        resolve(data);
      });
    });
    request.setTimeout(20000, () => request.destroy(new Error('Tiempo agotado al contactar con Google')));
    request.on('error', reject);
    request.end(body);
  });
}

function getJsonWithBearer(url, accessToken) {
  return new Promise((resolve, reject) => {
    const parsed = new URL(url);
    if (parsed.protocol !== 'https:' || parsed.hostname !== 'openidconnect.googleapis.com') {
      reject(new Error('Destino de perfil no permitido'));
      return;
    }
    const request = https.get(parsed, {
      headers: { Authorization: `Bearer ${accessToken}`, Accept: 'application/json', 'User-Agent': 'ẞetaMusic/1.1' },
    }, (response) => {
      let raw = '';
      response.setEncoding('utf8');
      response.on('data', chunk => { raw += chunk; });
      response.on('end', () => {
        if (response.statusCode < 200 || response.statusCode >= 300) {
          reject(new Error(`Google no devolvió el perfil (HTTP ${response.statusCode})`));
          return;
        }
        try { resolve(JSON.parse(raw)); } catch { reject(new Error('Respuesta de perfil no válida')); }
      });
    });
    request.setTimeout(15000, () => request.destroy(new Error('Tiempo agotado al consultar el perfil de Google')));
    request.on('error', reject);
  });
}

async function signInWithGoogle() {
  const config = readGoogleAuthConfig();
  if (!config.configured) return { ok: false, reason: 'not-configured' };

  const verifier = crypto.randomBytes(48).toString('base64url');
  const challenge = crypto.createHash('sha256').update(verifier).digest('base64url');
  const expectedState = crypto.randomBytes(32).toString('base64url');
  let server = null;
  let timeout = null;
  let redirectUri = '';

  try {
    const callbackResult = await new Promise((resolve, reject) => {
      let settled = false;
      const finish = (error, value) => {
        if (settled) return;
        settled = true;
        if (timeout) clearTimeout(timeout);
        if (error) reject(error); else resolve(value);
      };

      server = http.createServer((request, response) => {
        let requestUrl;
        try { requestUrl = new URL(request.url, redirectUri || 'http://127.0.0.1'); }
        catch { response.writeHead(400); response.end('Solicitud no válida.'); return; }
        if (requestUrl.pathname !== '/oauth2callback') {
          response.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
          response.end('Ruta no encontrada.');
          return;
        }
        if (requestUrl.searchParams.get('state') !== expectedState) {
          response.writeHead(400, { 'Content-Type': 'text/plain; charset=utf-8' });
          response.end('La comprobación de seguridad no coincide. Puedes cerrar esta ventana.');
          return;
        }
        const oauthError = requestUrl.searchParams.get('error');
        if (oauthError) {
          response.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
          response.end('<!doctype html><meta charset="utf-8"><title>ẞetaMusic</title><p>Inicio de sesión cancelado. Puedes volver a ẞetaMusic.</p>');
          finish(new Error(oauthError === 'access_denied' ? 'Inicio de sesión cancelado por el usuario.' : `Google devolvió: ${oauthError}`));
          return;
        }
        const code = requestUrl.searchParams.get('code');
        if (!code) {
          response.writeHead(400, { 'Content-Type': 'text/plain; charset=utf-8' });
          response.end('Google no devolvió un código de autorización.');
          finish(new Error('Google no devolvió un código de autorización.'));
          return;
        }
        response.writeHead(200, {
          'Content-Type': 'text/html; charset=utf-8',
          'Cache-Control': 'no-store',
          'X-Content-Type-Options': 'nosniff',
          'Content-Security-Policy': "default-src 'none'; style-src 'unsafe-inline'",
        });
        response.end('<!doctype html><html lang="es"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>ẞetaMusic</title><body style="font-family:system-ui;background:#090b13;color:#f4f5ff;display:grid;place-items:center;min-height:90vh"><main style="max-width:520px;padding:32px;text-align:center"><h1>Acceso completado</h1><p>Ya puedes volver a ẞetaMusic. Puedes cerrar esta pestaña.</p></main></body></html>');
        finish(null, { code });
      });

      timeout = setTimeout(() => finish(new Error('El inicio de sesión tardó demasiado. Inténtalo otra vez.')), GOOGLE_AUTH_TIMEOUT_MS);
      if (timeout.unref) timeout.unref();
      server.on('error', (error) => finish(error));
      server.listen(0, '127.0.0.1', async () => {
        try {
          const address = server.address();
          redirectUri = `http://127.0.0.1:${address.port}/oauth2callback`;
          const params = new URLSearchParams({
            client_id: config.clientId,
            redirect_uri: redirectUri,
            response_type: 'code',
            scope: 'openid email profile',
            state: expectedState,
            code_challenge: challenge,
            code_challenge_method: 'S256',
            prompt: 'select_account',
          });
          await shell.openExternal(`https://accounts.google.com/o/oauth2/v2/auth?${params.toString()}`);
        } catch (error) {
          finish(new Error(`No se pudo abrir el navegador para Google: ${error.message || error}`));
        }
      });
    });

    const tokenData = await postFormJson('https://oauth2.googleapis.com/token', {
      client_id: config.clientId,
      ...(config.clientSecret ? { client_secret: config.clientSecret } : {}),
      code: callbackResult.code,
      code_verifier: verifier,
      grant_type: 'authorization_code',
      redirect_uri: redirectUri,
    });
    if (!tokenData.access_token) throw new Error('Google no entregó un token de acceso. Revisa el cliente OAuth.');

    const user = await getJsonWithBearer('https://openidconnect.googleapis.com/v1/userinfo', tokenData.access_token);
    if (!user.sub || !user.email || user.email_verified !== true) {
      throw new Error('Google no confirmó una dirección de correo verificada.');
    }
    // No se guarda el token ni se transmite el perfil a ningún servidor de ẞetaMusic.
    return {
      ok: true,
      profile: {
        id: String(user.sub),
        email: String(user.email),
        name: String(user.name || user.given_name || user.email),
        picture: String(user.picture || ''),
        verified: true,
        authenticatedAt: Date.now(),
      },
    };
  } finally {
    if (timeout) clearTimeout(timeout);
    if (server) {
      try { server.close(); } catch {}
    }
  }
}

ipcMain.handle('auro-auth-google-status', async () => {
  const config = readGoogleAuthConfig();
  return { configured: config.configured, configPath: getGoogleAuthConfigPath() };
});

ipcMain.handle('auro-auth-google-sign-in', async () => {
  try { return await signInWithGoogle(); }
  catch (error) {
    return { ok: false, reason: 'error', message: String(error?.message || error) };
  }
});

ipcMain.handle('auro-system-info', async () => {
  const cpuList = os.cpus() || [];
  const threads = cpuList.length || 1;
  const ramGb = Math.round((os.totalmem() / (1024 ** 3)) * 10) / 10;
  let gpuDescription = 'GPU no identificada';
  try {
    const gpuInfo = await app.getGPUInfo('basic');
    const descriptions = (gpuInfo.gpuDevice || [])
      .map(device => [device.vendorString, device.deviceString].filter(Boolean).join(' '))
      .filter(Boolean);
    if (descriptions.length) gpuDescription = [...new Set(descriptions)].join(' / ');
    else if (gpuInfo.auxAttributes?.glRenderer) gpuDescription = String(gpuInfo.auxAttributes.glRenderer);
  } catch { /* El perfil sigue funcionando si el controlador no expone información de GPU. */ }

  // Las Intel HD antiguas suelen sufrir con Glass y desenfoques; bajamos el perfil recomendado
  // solo cuando además el equipo no tiene una reserva alta de CPU/RAM.
  const olderIntelHd = /Intel[^|]*(?:HD Graphics\s*(?:2\d{3}|3\d{3}|4\d{3}|5\d{3}|6\d{3}))/i.test(gpuDescription);
  let recommendedProfile = 'low';
  if (ramGb >= 12 && threads >= 8 && !olderIntelHd) recommendedProfile = 'high';
  else if (ramGb >= 6 && threads >= 4 && !(olderIntelHd && (ramGb < 12 || threads < 8))) recommendedProfile = 'balanced';
  return {
    ramGb,
    logicalThreads: threads,
    cpuModel: cpuList[0]?.model || 'CPU no identificada',
    gpuDescription,
    platform: process.platform,
    recommendedProfile,
  };
});

function createWindow() {
  const win = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 1050,
    minHeight: 680,
    backgroundColor: '#07090f',
    show: false,
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      preload: path.join(__dirname, 'preload.js'),
    },
    icon: path.join(__dirname, 'icon.ico'),
    title: 'ẞetaMusic 1.1',
  });

  win.loadFile(path.join(__dirname, 'index.html'));
  win.once('ready-to-show', () => win.show());
}

app.whenReady().then(() => {
  try {
    const userConfig = getGoogleAuthConfigPath();
    if (!fs.existsSync(userConfig)) {
      const bundledTemplate = path.join(__dirname, 'google-auth-config.json');
      if (fs.existsSync(bundledTemplate)) fs.copyFileSync(bundledTemplate, userConfig);
      else fs.writeFileSync(userConfig, JSON.stringify({ clientId: 'YOUR_GOOGLE_DESKTOP_OAUTH_CLIENT_ID.apps.googleusercontent.com', clientSecret: '' }, null, 2));
    }
  } catch (error) { console.warn('No se pudo preparar la configuración de Google:', error); }
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
