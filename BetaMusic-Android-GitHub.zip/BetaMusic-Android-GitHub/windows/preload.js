const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('auroOnline', {
  fetchJson: (url) => ipcRenderer.invoke('auro-online-fetch-json', url),
});

contextBridge.exposeInMainWorld('auroAuth', {
  getStatus: () => ipcRenderer.invoke('auro-auth-google-status'),
  signInWithGoogle: () => ipcRenderer.invoke('auro-auth-google-sign-in'),
  getSystemInfo: () => ipcRenderer.invoke('auro-system-info'),
});
