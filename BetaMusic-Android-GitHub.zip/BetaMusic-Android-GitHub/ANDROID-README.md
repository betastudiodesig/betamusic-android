# ẞetaMusic Android — notas técnicas

## Compilación sin Android Studio

Este proyecto está configurado para que GitHub Actions obtenga el SDK, genere `android/` con Capacitor y compile un APK. El workflow está en `.github/workflows/build-android.yml`.

## Compilación local opcional desde CMD de Windows

Solo es necesaria si Node.js 22, JDK 21 y el Android SDK Command-line Tools ya están instalados y configurados. No requiere abrir Android Studio, pero sí requiere el SDK.

```bat
cd android-app
npm install
npx cap add android
node ..\scripts\prepare-android-native.mjs android
npx cap sync android
cd android
gradlew.bat assembleDebug
```

Salida esperada: `android-app\android\app\build\outputs\apk\debug\app-debug.apk`.

## Funciones que necesitan integración aparte

- Google OAuth: deshabilitado en el puente móvil para no aparentar autenticación verificada.
- Selección de carpetas: el selector Android varía por fabricante; usar `+ Música` para seleccionar archivos.
- Audio en segundo plano/controles nativos: `Media Session` del navegador puede funcionar según el WebView, pero no sustituye a un servicio de reproducción Android persistente.
- Importación de la biblioteca del PC: las bases IndexedDB de Windows y Android son independientes.
