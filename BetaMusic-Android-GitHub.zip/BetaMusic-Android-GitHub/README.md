# ẞetaMusic Android — proyecto preparado para GitHub Actions

Este proyecto parte de **ẞetaMusic 1.1** y separa el código Electron de Windows de una versión web empaquetable con Capacitor para Android. La compilación de Android se realiza en GitHub Actions, por lo que no hace falta instalar Android Studio ni Gradle en el PC local.

## Carpetas

- `windows/`: copia del proyecto original Electron ẞetaMusic 1.1. No se sustituye ni se elimina.
- `android-app/www/`: interfaz que se empaqueta dentro de la aplicación Android.
- `android-app/package.json`: dependencias de Capacitor fijadas a 8.5.3.
- `android-app/capacitor.config.json`: identificador `com.beta.betamusic` y nombre de la aplicación.
- `.github/workflows/build-android.yml`: workflow que genera y compila el proyecto nativo, crea el APK y publica el APK como artefacto descargable.
- `android-assets/`: iconos adaptativos y de diferentes densidades.
- `scripts/prepare-android-native.mjs`: copia los iconos al proyecto nativo generado por Capacitor.

La carpeta nativa `android-app/android/` no se incluye en el ZIP porque la genera el workflow con la versión exacta de Capacitor instalada. Así se evita arrastrar cachés o proyectos Gradle incompletos en el ZIP.

## Qué hace la versión Android

Conserva la interfaz de ẞetaMusic 1.1 y el motor web existente, incluida la biblioteca local IndexedDB, playlists, favoritos, cola, recomendaciones y controles de audio que ya implementa el frontend. El acceso a música se hace mediante el selector de archivos Android desde el botón `+ Música`.

El acceso a carpetas mediante `webkitdirectory`, el inicio de sesión de Google, la reproducción en segundo plano y los controles multimedia nativos necesitan pruebas o integración Android adicional. No se simula que esas funciones estén terminadas. La biblioteca del PC no se copia automáticamente al teléfono; se importan canciones desde el dispositivo.

## Generar el APK en GitHub Actions

1. Crea un repositorio nuevo en GitHub.
2. Sube el contenido completo de esta carpeta al repositorio, incluida la carpeta oculta `.github`.
3. Abre la pestaña **Actions** del repositorio.
4. Selecciona **Build ẞetaMusic APK** y pulsa **Run workflow**. También se ejecuta al subir cambios a `main` o `master`.
5. Espera a que el trabajo termine correctamente y abre esa ejecución.
6. En **Artifacts**, descarga `BetaMusic-Android-debug-APK` y descomprime el ZIP. Dentro estará `app-debug.apk`.
7. Transfiere el APK al teléfono e instálalo. Android puede pedir autorización para instalar aplicaciones desde el gestor de archivos utilizado.

El workflow compila un APK de depuración para pruebas. No es un APK de lanzamiento firmado para publicar en Google Play.

## Dependencias de la compilación en la nube

- Node.js 22
- JDK 21
- Android SDK Platform 36 y Build Tools 36.0.0
- Capacitor 8.5.3

El workflow descarga y genera el proyecto nativo en sus propios pasos; no requiere Android Studio en el equipo de casa.

## Revisiones realizadas

Se revisa la sintaxis de `app.js` y el puente web Android antes de iniciar Gradle. Este entorno no pudo descargar paquetes de npm ni ejecutar Gradle por no disponer de una ruta funcional a los repositorios de paquetes; por eso la compilación definitiva debe confirmarse con el resultado de GitHub Actions. Si falla, el workflow intenta adjuntar los informes de compilación.
