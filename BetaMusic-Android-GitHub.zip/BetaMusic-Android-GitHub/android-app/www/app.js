(() => {
  'use strict';

  try { if (window.localStorage.getItem('auro-startup-animation-enabled') === 'false') document.documentElement.classList.add('startup-animation-off'); } catch {}

  const DB_NAME = 'aurora-player-db';
  const DB_VERSION = 3;
  const SONG_STORE = 'songs';
  const SETTINGS_STORE = 'settings';
  const PLAYLIST_STORE = 'playlists';
  const HISTORY_STORE = 'history';
  const SETTINGS_KEY = 'player-state';
  const JS_TAG_FIELDS = ['title', 'artist', 'album', 'genre', 'picture', 'track', 'tracknumber', 'disc', 'year', 'lyrics', 'unsyncedlyrics', 'USLT', 'replaygain_track_gain', 'replaygain_album_gain'];
  const $ = (selector) => document.querySelector(selector);
  const els = {
    audio: $('#audio'), filePicker: $('#filePicker'), folderPicker: $('#folderPicker'), addMusicBtn: $('#addMusicBtn'), clearLibraryBtn: $('#clearLibraryBtn'), chooseLibraryFolderBtn: $('#chooseLibraryFolderBtn'), libraryFolderStatus: $('#libraryFolderStatus'),
    librarySearch: $('#librarySearch'), libraryBody: $('#libraryBody'), sectionTitle: $('#sectionTitle'), viewDescription: $('#viewDescription'), libraryToolbarActions: $('#libraryToolbarActions'),
    libraryStatus: $('#libraryStatus'), storageStatus: $('#storageStatus'), statsStatus: $('#statsStatus'), queueList: $('#queueList'), queueCount: $('#queueCount'),
    coverArt: $('#coverArt'), coverFallback: $('#coverFallback'), nowTitle: $('#nowTitle'), nowArtist: $('#nowArtist'), nowAlbum: $('#nowAlbum'), nowFavoriteBtn: $('#nowFavoriteBtn'), nowAddPlaylistBtn: $('#nowAddPlaylistBtn'), nowLyricsBtn: $('#nowLyricsBtn'), nowSongActionsBtn: $('#nowSongActionsBtn'), lyricsOverlay: $('#lyricsOverlay'), closeLyricsBtn: $('#closeLyricsBtn'), lyricsTitle: $('#lyricsTitle'), lyricsSubtitle: $('#lyricsSubtitle'), lyricsContent: $('#lyricsContent'), lyricsSource: $('#lyricsSource'), lyricsRetryBtn: $('#lyricsRetryBtn'), seekFill: $('#seekFill'), seekHead: $('#seekHead'), startupIntro: $('#startupIntro'),
    currentTime: $('#currentTime'), duration: $('#duration'), seekBar: $('#seekBar'), volumeBar: $('#volumeBar'), volumeLabel: $('#volumeLabel'), playBtn: $('#playBtn'), prevBtn: $('#prevBtn'), nextBtn: $('#nextBtn'), shuffleBtn: $('#shuffleBtn'), repeatBtn: $('#repeatBtn'),
    toggleEq: $('#toggleEq'), togglePlaylist: $('#togglePlaylist'), playlistPanel: $('#playlistPanel'), toast: $('#toast'), qualityPill: $('#qualityPill'), backdrop: $('.backdrop'),
    settingsBtn: $('#settingsBtn'), settingsOverlay: $('#settingsOverlay'), closeSettingsBtn: $('#closeSettingsBtn'), performanceModeToggle: $('#performanceModeToggle'), glassEffectToggle: $('#glassEffectToggle'), transparencyToggle: $('#transparencyToggle'), animationsToggle: $('#animationsToggle'), dynamicBackgroundToggle: $('#dynamicBackgroundToggle'), startupAnimationToggle: $('#startupAnimationToggle'), googleAccountBtn: $('#googleAccountBtn'), googleAccountStatus: $('#googleAccountStatus'), crossfadeToggle: $('#crossfadeToggle'), crossfadeSeconds: $('#crossfadeSeconds'), gaplessToggle: $('#gaplessToggle'), replayGainToggle: $('#replayGainToggle'), limiterToggle: $('#limiterToggle'), fadeInToggle: $('#fadeInToggle'), fadeInSeconds: $('#fadeInSeconds'), fadeOutToggle: $('#fadeOutToggle'), fadeOutSeconds: $('#fadeOutSeconds'),
    queueCurrentBtn: $('#queueCurrentBtn'), playlistCurrentBtn: $('#playlistCurrentBtn'), clearQueueBtn: $('#clearQueueBtn'), saveQueueBtn: $('#saveQueueBtn'), newPlaylistBtn: $('#newPlaylistBtn'),
    playlistModal: $('#playlistModal'), playlistNameInput: $('#playlistNameInput'), confirmPlaylistBtn: $('#confirmPlaylistBtn'), cancelPlaylistBtn: $('#cancelPlaylistBtn'), closePlaylistModal: $('#closePlaylistModal'),
    playlistPickerModal: $('#playlistPickerModal'), playlistPickerList: $('#playlistPickerList'), closePickerModal: $('#closePickerModal'), createFromPickerBtn: $('#createFromPickerBtn'), onlineConnectBtn: $('#onlineConnectBtn'), settingsOnlineBtn: $('#settingsOnlineBtn'), onlineSettingsOverlay: $('#onlineSettingsOverlay'), closeOnlineSettingsBtn: $('#closeOnlineSettingsBtn'), cancelOnlineBtn: $('#cancelOnlineBtn'), saveOnlineBtn: $('#saveOnlineBtn'), disconnectOnlineBtn: $('#disconnectOnlineBtn'), jamendoClientIdInput: $('#jamendoClientIdInput'), onlineStatus: $('#onlineStatus')
  };
  const state = {
    library: [], playlists: [], history: [], queueIds: [], queueIndex: -1, currentId: null, view: 'songs', query: '',
    shuffle: false, repeat: 'off', volume: 0.9, playlistOpen: true, resumeTime: 0, restoredTime: 0, performanceMode: false, performanceRestore: null, glassEnabled: true, transparencyEnabled: true, animationsEnabled: true, eqBands: Array(10).fill(0), bassBoost: 0, balance: 0, theme: 'violet', compactMode: false, miniPlayer: false,
    libraryViewMode: 'list', dynamicBackgroundEnabled: false, albumDetail: null, artistDetail: null, playlistDetailId: null, recommendationPage: 0, libraryFolderName: '', startupAnimationEnabled: true, performanceProfile: 'custom', onboardingComplete: false, googleAccount: null, crossfadeEnabled: true, crossfadeSeconds: 5, gaplessEnabled: true, replayGainEnabled: false, finalLimiterEnabled: true, fadeInEnabled: true, fadeInSeconds: 0.8, fadeOutEnabled: true, fadeOutSeconds: 0.8,
    pickerSongId: null, editingPlaylistId: null, onlineFavorites: [], jamendoClientId: '', onlineResults: [], onlineCurrentIndex: -1, onlineCurrentTrack: null, onlineLoading: false
  };
  let db = null, saveTimer = null, toastTimer = null, searchTimer = null, libraryTransitionTimer = null, libraryTransitionToken = 0, queueAnimationTimer = null, queueAnimationToken = 0, audioContext = null, sourceNode = null, secondarySource = null, masterGain = null, limiterNode = null, audioGraphReady = false, lastCountedPlayId = null, eqFilters = [], bassFilter = null, balanceNode = null, primaryDeckGain = null, secondaryDeckGain = null, secondaryAudio = null, activeDeck = 'primary', transitionTimer = null, transitionToken = 0, crossfadeStartedForId = null;
  const coverCache = new Map();
  let lastListenPosition = null, lastListenWriteAt = 0, lyricsRequestToken = 0;

  document.addEventListener('DOMContentLoaded', init);
  async function init() {
    bindEvents(); setupMediaSession(); createSecondaryDeck(); setVolume(state.volume); applyTheme(state.theme||'violet'); document.body.classList.toggle('compact-mode',Boolean(state.compactMode)); document.body.classList.toggle('mini-player-mode',Boolean(state.miniPlayer)); updatePanelVisibility(false); applyUiEffects();
    try {
      db = await openDatabase(); await restoreState(); await loadData(); const libraryModeControl=document.getElementById('libraryViewMode'); if(libraryModeControl) libraryModeControl.value=state.libraryViewMode||'list'; renderAll(); syncViewTabs(); syncLibraryFolderUI(); updatePanelVisibility(false); document.body.classList.toggle('compact-mode',Boolean(state.compactMode)); document.body.classList.toggle('mini-player-mode',Boolean(state.miniPlayer)); applyPerformanceMode(); applyUiEffects(); syncPlaybackSettingsUI(); setVolume(state.volume); updateOnlineStatus(); document.documentElement.classList.toggle('startup-animation-off', !state.startupAnimationEnabled); try { localStorage.setItem('auro-startup-animation-enabled', String(state.startupAnimationEnabled)); } catch {} finishStartupIntro(); syncGoogleAccountUI(); queueWelcomeExperience(); els.storageStatus.textContent = 'IndexedDB listo';
    } catch (error) { console.error(error); els.storageStatus.textContent = 'Almacenamiento no disponible'; showToast('No se pudo inicializar la biblioteca.'); finishStartupIntro(); syncGoogleAccountUI(); queueWelcomeExperience(); }
  }

  function bindEvents() {
    els.addMusicBtn.addEventListener('click', () => els.filePicker.click());
    els.filePicker.addEventListener('change', async (event) => { if (event.target.files?.length) { try { await importFiles([...event.target.files]); } catch(error) { console.error(error); showToast(`Error al importar: ${error.message||error}`); } } event.target.value = ''; });
    els.chooseLibraryFolderBtn?.addEventListener('click', () => els.folderPicker?.click());
    els.folderPicker?.addEventListener('change', async event => {
      const files = [...(event.target.files || [])];
      event.target.value = '';
      if (!files.length) return;
      const relative = files.find(file => file.webkitRelativePath)?.webkitRelativePath || '';
      const folderName = relative.split('/')[0] || 'Carpeta seleccionada';
      state.libraryFolderName = folderName;
      syncLibraryFolderUI();
      persistState();
      try { await importFiles(files, { folderName }); }
      catch (error) { console.error(error); showToast(`Error al leer la carpeta: ${error.message || error}`); }
    });
    document.addEventListener('click', handleEnhancedAction);
    document.body.addEventListener('dragover', (event) => { if (event.dataTransfer?.types?.includes('Files')) { event.preventDefault(); event.dataTransfer.dropEffect = 'copy'; } });
    document.body.addEventListener('drop', async (event) => { if (!event.dataTransfer?.files?.length) return; event.preventDefault(); await importFiles([...event.dataTransfer.files]); });
    els.librarySearch.addEventListener('input', (event) => { clearTimeout(searchTimer); searchTimer = setTimeout(() => { state.query = normalizeText(event.target.value); if(state.view === 'online') searchOnline(state.query); else renderLibrary(); }, 180); });
    document.querySelectorAll('.tab-btn').forEach((button) => button.addEventListener('click', () => switchView(button.dataset.view)));
    els.playBtn.addEventListener('click', togglePlay); els.prevBtn.addEventListener('click', playPrevious); els.nextBtn.addEventListener('click', () => playNext(true)); els.shuffleBtn.addEventListener('click', toggleShuffle); els.repeatBtn.addEventListener('click', cycleRepeat);
    els.clearLibraryBtn.addEventListener('click', clearLibrary); els.nowFavoriteBtn.addEventListener('click', () => state.currentId && toggleFavorite(state.currentId)); els.nowAddPlaylistBtn?.addEventListener('click', addCurrentSongToPlaylist); els.nowLyricsBtn?.addEventListener('click', openLyrics); els.closeLyricsBtn?.addEventListener('click', closeLyrics); els.lyricsRetryBtn?.addEventListener('click', () => openLyrics(true)); els.lyricsOverlay?.addEventListener('click', event => { if (event.target === els.lyricsOverlay) closeLyrics(); }); els.nowSongActionsBtn?.addEventListener('click', () => { if (state.onlineCurrentTrack) { showToast('Las acciones de edición están disponibles para canciones locales.'); return; } if (state.currentId) showSongActions(state.currentId); });
    els.queueCurrentBtn?.addEventListener('click', () => state.currentId && addToQueue(state.currentId)); els.playlistCurrentBtn?.addEventListener('click', () => state.currentId && openPlaylistPicker(state.currentId));
    els.clearQueueBtn?.addEventListener('click', clearQueue); els.saveQueueBtn?.addEventListener('click', saveQueueAsPlaylist); els.newPlaylistBtn?.addEventListener('click', () => openPlaylistModal());
    els.settingsBtn.addEventListener('click', openSettings); els.closeSettingsBtn.addEventListener('click', closeSettings); els.settingsOverlay.addEventListener('click', (e) => { if (e.target === els.settingsOverlay) closeSettings(); });
    els.googleAccountBtn?.addEventListener('click', handleGoogleAccountButton);
    document.getElementById('statsBtn').addEventListener('click', openStatsModal);
    document.getElementById('miniBtn').addEventListener('click', toggleMiniPlayer);
    bindPlaybackSettings();
    const libraryViewMode = document.getElementById('libraryViewMode'); if (libraryViewMode) { libraryViewMode.value = state.libraryViewMode || 'list'; libraryViewMode.addEventListener('change', () => { state.libraryViewMode = libraryViewMode.value === 'grid' ? 'grid' : 'list'; renderLibrary(); persistState(); }); }
    els.seekBar.addEventListener('input', () => { const value=Number(els.seekBar.value); updateSeekFill(value); if (Number.isFinite(els.audio.duration)) els.audio.currentTime = value / 100 * els.audio.duration; });
    els.volumeBar.addEventListener('input', () => { setVolume(Number(els.volumeBar.value)); persistState(); });
    els.audio.addEventListener('loadedmetadata', onMetadataLoaded); els.audio.addEventListener('timeupdate', onTimeUpdate);
    els.audio.addEventListener('play', () => { setPlayButtonState(true); resumeAudioContextIfNeeded(); }); els.audio.addEventListener('pause', () => { if(els.audio===document.getElementById('audio')) setPlayButtonState(false); resumeAudioContextIfNeeded(); });
    els.audio.addEventListener('ended', () => { if (!transitionTimer) handleEnded(); }); els.audio.addEventListener('error', () => showToast('Este archivo no se puede reproducir.'));
    els.toggleEq.addEventListener('click', () => openEqualizer()); els.togglePlaylist.addEventListener('click', () => { state.playlistOpen = !state.playlistOpen; updatePanelVisibility(); persistState(); });
    els.confirmPlaylistBtn.addEventListener('click', confirmPlaylist); els.cancelPlaylistBtn.addEventListener('click', closePlaylistModal); els.closePlaylistModal.addEventListener('click', closePlaylistModal);
    els.playlistModal.addEventListener('click', (e) => { if (e.target === els.playlistModal) closePlaylistModal(); }); els.closePickerModal.addEventListener('click', closePlaylistPicker); els.playlistPickerModal.addEventListener('click', (e) => { if (e.target === els.playlistPickerModal) closePlaylistPicker(); });
    els.createFromPickerBtn.addEventListener('click', () => { const songId = state.pickerSongId; closePlaylistPicker(); openPlaylistModal(null, songId); });
    els.onlineConnectBtn?.addEventListener('click', openOnlineSettings); els.settingsOnlineBtn?.addEventListener('click', openOnlineSettings); els.closeOnlineSettingsBtn?.addEventListener('click', closeOnlineSettings); els.cancelOnlineBtn?.addEventListener('click', closeOnlineSettings); els.onlineSettingsOverlay?.addEventListener('click', (e) => { if(e.target===els.onlineSettingsOverlay) closeOnlineSettings(); }); els.saveOnlineBtn?.addEventListener('click', saveOnlineSettings); els.disconnectOnlineBtn?.addEventListener('click', disconnectOnline); els.jamendoClientIdInput?.addEventListener('keydown', e=>{ if(e.key==='Enter') saveOnlineSettings(); });
    document.addEventListener('visibilitychange', resumeAudioContextIfNeeded);
    document.addEventListener('keydown', (event) => {
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') { event.preventDefault(); els.librarySearch.focus(); els.librarySearch.select(); }
      if (event.code === 'Space' && !['INPUT','TEXTAREA'].includes(document.activeElement?.tagName)) { event.preventDefault(); togglePlay(); }
      if (event.altKey && event.key === 'ArrowRight') playNext(true); if (event.altKey && event.key === 'ArrowLeft') playPrevious(); if (event.key === 'Escape') { closeSettings(); closePlaylistModal(); closePlaylistPicker(); closeLyrics(); }
    });
  }

  function syncViewTabs() {
    document.querySelectorAll('.tab-btn').forEach(tab => tab.classList.toggle('active', tab.dataset.view === state.view));
  }
  function switchView(view) {
    if (!view || view === state.view) return;
    state.view = view;
    if (view !== 'albums') state.albumDetail = null;
    if (view !== 'artists') state.artistDetail = null;
    if (view !== 'playlists') state.playlistDetailId = null;
    syncViewTabs();
    if (view === 'playlists' || view === 'albums' || view === 'recommendations') { state.query = ''; els.librarySearch.value = ''; }
    else state.query = normalizeText(els.librarySearch.value || '');
    animateLibraryRender(() => {
      if (view === 'online') {
        els.librarySearch.placeholder = 'Buscar música online...';
        renderOnlineHome();
        if (state.jamendoClientId && !state.onlineResults.length) searchOnline(state.query || '');
      } else {
        els.librarySearch.placeholder = 'Buscar canción, artista, álbum o playlist...';
        renderLibrary();
      }
    });
    persistState();
  }

  function animateLibraryRender(render) {
    const body = els.libraryBody;
    const token = ++libraryTransitionToken;
    clearTimeout(libraryTransitionTimer);
    body.classList.remove('view-entering');
    body.classList.add('view-leaving');
    libraryTransitionTimer = setTimeout(() => {
      if (token !== libraryTransitionToken) return;
      render();
      body.classList.remove('view-leaving');
      body.classList.add('view-entering');
      libraryTransitionTimer = setTimeout(() => {
        if (token === libraryTransitionToken) body.classList.remove('view-entering');
      }, 420);
    }, 95);
  }

  function openDatabase() {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);
      request.onupgradeneeded = () => {
        const database = request.result;
        if (!database.objectStoreNames.contains(SONG_STORE)) database.createObjectStore(SONG_STORE, { keyPath: 'id' });
        if (!database.objectStoreNames.contains(SETTINGS_STORE)) database.createObjectStore(SETTINGS_STORE, { keyPath: 'key' });
        if (!database.objectStoreNames.contains(PLAYLIST_STORE)) database.createObjectStore(PLAYLIST_STORE, { keyPath: 'id' });
        if (!database.objectStoreNames.contains(HISTORY_STORE)) {
          const history = database.createObjectStore(HISTORY_STORE, { keyPath: 'id', autoIncrement: true });
          history.createIndex('songId', 'songId', { unique: false });
          history.createIndex('playedAt', 'playedAt', { unique: false });
        } else {
          const history = request.transaction.objectStore(HISTORY_STORE);
          if (!history.indexNames.contains('songId')) history.createIndex('songId', 'songId', { unique: false });
          if (!history.indexNames.contains('playedAt')) history.createIndex('playedAt', 'playedAt', { unique: false });
        }
        const songs = request.transaction.objectStore(SONG_STORE);
        if (!songs.indexNames.contains('sourceKey')) songs.createIndex('sourceKey', 'sourceKey', { unique: false });
      };
      request.onsuccess = () => {
        const database = request.result;
        database.onversionchange = () => database.close();
        resolve(database);
      };
      request.onerror = () => reject(request.error || new Error('IndexedDB error'));
      request.onblocked = () => console.warn('La actualización de la base de datos está bloqueada por otra ventana de ẞetaMusic.');
    });
  }
  function tx(storeName, mode = 'readonly') { return db.transaction(storeName, mode).objectStore(storeName); }
  function idbRequest(request) { return new Promise((resolve, reject) => { request.onsuccess = () => resolve(request.result); request.onerror = () => reject(request.error); }); }
  function transactionDone(transaction) {
    return new Promise((resolve, reject) => {
      transaction.oncomplete = () => resolve();
      transaction.onerror = () => reject(transaction.error || new Error('Error de IndexedDB'));
      transaction.onabort = () => reject(transaction.error || new Error('Transacción cancelada'));
    });
  }
  function readLegacyPlaylistArrays() {
    const result = [];
    for (const key of ['auro-playlists', 'aurora-player-playlists', 'auro.music.playlists']) {
      try {
        const value = JSON.parse(localStorage.getItem(key) || 'null');
        if (Array.isArray(value)) result.push(...value);
      } catch {}
    }
    return result;
  }
  function normalizePlaylistRecord(raw) {
    if (!raw || typeof raw !== 'object') return null;
    const sourceIds = Array.isArray(raw.songIds) ? raw.songIds
      : Array.isArray(raw.songIDs) ? raw.songIDs
      : Array.isArray(raw.songs) ? raw.songs
      : Array.isArray(raw.tracks) ? raw.tracks
      : Array.isArray(raw.items) ? raw.items : [];
    const ids = sourceIds.map(item => {
      if (item && typeof item === 'object') return item.songId ?? item.trackId ?? item.track_id ?? item.id ?? item.songID ?? null;
      return item;
    }).filter(id => id !== null && id !== undefined && String(id).trim() !== '').map(String);
    const now = Date.now();
    return {
      id: String(raw.id ?? raw.uuid ?? raw.playlistId ?? raw.playlist_id ?? crypto.randomUUID()),
      name: String(raw.name ?? raw.title ?? raw.playlistName ?? raw.playlist_name ?? 'Playlist importada').trim() || 'Playlist importada',
      songIds: [...new Set(ids)],
      createdAt: Number(raw.createdAt ?? raw.created_at ?? raw.created ?? raw.timestamp) || now,
      updatedAt: Number(raw.updatedAt ?? raw.updated_at) || now
    };
  }
  async function savePlaylistRecords(records) {
    if (!db || !records.length) return;
    const transaction = db.transaction(PLAYLIST_STORE, 'readwrite');
    const store = transaction.objectStore(PLAYLIST_STORE);
    records.forEach(record => store.put(record));
    await transactionDone(transaction);
  }
  async function loadData() {
    state.library = await idbRequest(tx(SONG_STORE).getAll());
    const storedPlaylists = await idbRequest(tx(PLAYLIST_STORE).getAll());
    state.history = await idbRequest(tx(HISTORY_STORE).getAll());
    // Older builds used different property names for playlists. Normalize and migrate them
    // instead of silently dropping records that still exist in IndexedDB or old state.
    const candidates = [...storedPlaylists, ...(Array.isArray(state.playlists) ? state.playlists : []), ...readLegacyPlaylistArrays()];
    const byId = new Map();
    for (const candidate of candidates) {
      const playlist = normalizePlaylistRecord(candidate);
      if (!playlist) continue;
      const existing = byId.get(playlist.id);
      if (!existing || playlist.updatedAt >= existing.updatedAt) byId.set(playlist.id, playlist);
    }
    state.playlists = [...byId.values()].sort((a, b) => a.createdAt - b.createdAt);
    // Repair playlist entries that contain song metadata instead of the current IDs.
    let repaired = false;
    for (const playlist of state.playlists) {
      const legacySource = candidates.find(candidate => String(candidate?.id ?? candidate?.uuid ?? candidate?.playlistId ?? candidate?.playlist_id ?? '') === playlist.id && (Array.isArray(candidate?.songs) || Array.isArray(candidate?.tracks)))
        || candidates.find(candidate => String(candidate?.id ?? candidate?.uuid ?? candidate?.playlistId ?? candidate?.playlist_id ?? '') === playlist.id);
      const embeddedSongs = Array.isArray(legacySource?.songs) ? legacySource.songs : Array.isArray(legacySource?.tracks) ? legacySource.tracks : [];
      for (const item of embeddedSongs) {
        if (!item || typeof item !== 'object') continue;
        const legacyId = item.songId ?? item.trackId ?? item.track_id ?? item.id ?? item.songID;
        let match = legacyId !== undefined && legacyId !== null ? songById(String(legacyId)) : null;
        if (!match) match = state.library.find(song => (item.sourceKey && song.sourceKey === item.sourceKey) ||
          (normalizeText(item.title || item.name) === normalizeText(song.title) && normalizeText(item.artist || '') === normalizeText(song.artist) && normalizeText(item.album || '') === normalizeText(song.album)));
        if (match && !playlist.songIds.includes(match.id)) { playlist.songIds.push(match.id); repaired = true; }
      }
    }
    if (state.playlists.length && (storedPlaylists.length !== state.playlists.length || repaired || state.playlists.some(p => !storedPlaylists.some(old => old.id === p.id && Array.isArray(old.songIds) && old.name === p.name)))) {
      await savePlaylistRecords(state.playlists);
    }
    state.library.forEach(song => { song.title = cleanText(song.title) || String(song.name || 'Canción').replace(/\.[^.]+$/, ''); song.artist = cleanText(song.artist) || 'Artista desconocido'; song.album = cleanText(song.album) || 'Álbum desconocido'; song.genre = cleanText(song.genre) || 'Sin género'; song.listenSeconds = Math.max(0, Number(song.listenSeconds) || 0); song.lyrics = String(song.lyrics || ''); song.externalPlainLyrics = String(song.externalPlainLyrics || ''); song.externalSyncedLyrics = String(song.externalSyncedLyrics || ''); if (!Number.isFinite(Number(song.trackNumber))) song.trackNumber = parseLeadingNumber(song.trackNumber || song.track); if (!Number.isFinite(Number(song.discNumber))) song.discNumber = parseLeadingNumber(song.discNumber || song.disc); });
    state.library.sort((a, b) => (a.addedAt || 0) - (b.addedAt || 0));
    state.history.sort((a, b) => (b.playedAt || 0) - (a.playedAt || 0));
    const valid = new Set(state.library.map(song => song.id));
    state.queueIds = (Array.isArray(state.queueIds) ? state.queueIds : []).filter(id => valid.has(id));
    if (!state.queueIds.length) state.queueIds = state.shuffle ? smartShuffledIds([...valid]) : [...valid];
    if (state.currentId && valid.has(state.currentId)) state.queueIndex = state.queueIds.indexOf(state.currentId);
    else { state.currentId = state.queueIds[0] || null; state.queueIndex = state.currentId ? state.queueIds.indexOf(state.currentId) : -1; state.restoredTime = 0; }
    if (state.currentId) await setCurrentTrack(state.currentId, { autoplay: false, restoreTime: state.restoredTime });
  }
  async function clearLibrary() {
    if (!confirm('¿Borrar toda la biblioteca, playlists e historial?\n\nEsta acción no se puede deshacer.')) return;
    try {
      els.audio.pause(); releaseAudioUrl(); els.audio.removeAttribute('src'); els.audio.load();
      await Promise.all([idbRequest(tx(SONG_STORE,'readwrite').clear()), idbRequest(tx(PLAYLIST_STORE,'readwrite').clear()), idbRequest(tx(HISTORY_STORE,'readwrite').clear())]);
      for (const url of coverCache.values()) if (url.startsWith('blob:')) URL.revokeObjectURL(url); coverCache.clear();
      Object.assign(state, { library: [], playlists: [], history: [], queueIds: [], queueIndex: -1, currentId: null, query: '', albumDetail: null, playlistDetailId: null, resumeTime: 0, restoredTime: 0, libraryFolderName: '' }); syncLibraryFolderUI(); els.librarySearch.value = ''; renderAll(); persistState(); showToast('Biblioteca eliminada.');
    } catch (error) { console.error(error); showToast('No se pudo borrar la biblioteca.'); }
  }
  async function restoreState() {
    const saved = await idbRequest(tx(SETTINGS_STORE).get(SETTINGS_KEY)); if (!saved?.value) { try { const startupPref=localStorage.getItem('auro-startup-animation-enabled'); if(startupPref!==null) state.startupAnimationEnabled=startupPref==='true'; } catch {} return; } Object.assign(state, saved.value); state.volume = clamp(Number(state.volume),0,1); state.crossfadeSeconds=clamp(Number(state.crossfadeSeconds??5),1,12); state.fadeInSeconds=clamp(Number(state.fadeInSeconds??0.8),0,5); state.fadeOutSeconds=clamp(Number(state.fadeOutSeconds??0.8),0,5); state.repeat = ['off','all','one'].includes(state.repeat) ? state.repeat : 'off'; state.view = ['songs','favorites','playlists','recent','most','recommendations','albums','artists','online'].includes(state.view) ? state.view : 'songs'; state.libraryViewMode = state.libraryViewMode === 'grid' ? 'grid' : 'list';
    state.onlineFavorites = Array.isArray(state.onlineFavorites) ? state.onlineFavorites : [];
    state.jamendoClientId = String(state.jamendoClientId || ''); state.performanceMode = Boolean(state.performanceMode);
    state.glassEnabled = state.glassEnabled !== false; state.transparencyEnabled = state.transparencyEnabled !== false; state.animationsEnabled = state.animationsEnabled !== false; state.dynamicBackgroundEnabled = state.dynamicBackgroundEnabled === true; state.startupAnimationEnabled = state.startupAnimationEnabled !== false;
    if (state.performanceMode) { if (!state.performanceRestore || typeof state.performanceRestore !== 'object') state.performanceRestore = { glassEnabled: state.glassEnabled, transparencyEnabled: state.transparencyEnabled, animationsEnabled: state.animationsEnabled }; state.glassEnabled = false; state.transparencyEnabled = false; state.animationsEnabled = false; }
    try { const startupPref = localStorage.getItem('auro-startup-animation-enabled'); if (startupPref !== null) state.startupAnimationEnabled = startupPref === 'true'; } catch {}
    state.performanceProfile = ['high','balanced','low','custom'].includes(state.performanceProfile) ? state.performanceProfile : 'custom'; state.onboardingComplete = Boolean(state.onboardingComplete); state.googleAccount = state.googleAccount && typeof state.googleAccount === 'object' ? state.googleAccount : null;
    try { const savedAccount = localStorage.getItem('auro-google-profile-v1'); if (savedAccount) state.googleAccount = JSON.parse(savedAccount); } catch {}
    state.albumDetail = null; state.playlistDetailId = null; state.query = ''; state.libraryFolderName = String(state.libraryFolderName || ''); state.recommendationPage = Math.max(0, Number(state.recommendationPage) || 0); state.restoredTime = Number(state.resumeTime) || 0;
  }
  function persistState(extra={}) {
    clearTimeout(saveTimer); saveTimer=setTimeout(async()=>{ if(!db)return; const value={queueIds:state.queueIds,queueIndex:state.queueIndex,currentId:state.currentId,view:state.view,shuffle:state.shuffle,repeat:state.repeat,volume:state.volume,playlistOpen:state.playlistOpen,performanceMode:state.performanceMode,performanceRestore:state.performanceRestore,glassEnabled:state.glassEnabled,transparencyEnabled:state.transparencyEnabled,animationsEnabled:state.animationsEnabled,dynamicBackgroundEnabled:state.dynamicBackgroundEnabled,startupAnimationEnabled:state.startupAnimationEnabled,performanceProfile:state.performanceProfile,onboardingComplete:state.onboardingComplete,googleAccount:state.googleAccount,libraryViewMode:state.libraryViewMode,eqBands:state.eqBands,bassBoost:state.bassBoost,balance:state.balance,theme:state.theme,compactMode:state.compactMode,miniPlayer:state.miniPlayer,crossfadeEnabled:state.crossfadeEnabled,crossfadeSeconds:state.crossfadeSeconds,gaplessEnabled:state.gaplessEnabled,replayGainEnabled:state.replayGainEnabled,finalLimiterEnabled:state.finalLimiterEnabled,fadeInEnabled:state.fadeInEnabled,fadeInSeconds:state.fadeInSeconds,fadeOutEnabled:state.fadeOutEnabled,fadeOutSeconds:state.fadeOutSeconds,resumeTime:Number(els.audio.currentTime||0),onlineFavorites:state.onlineFavorites,jamendoClientId:state.jamendoClientId,libraryFolderName:state.libraryFolderName,recommendationPage:state.recommendationPage,...extra}; try{await idbRequest(tx(SETTINGS_STORE,'readwrite').put({key:SETTINGS_KEY,value}));}catch(e){console.warn(e);}},150);
  }

  async function importFiles(files, options = {}) {
    const existing = new Set(state.library.map(s => s.sourceKey)); const additions=[];
    if (options.folderName) { state.libraryFolderName = options.folderName; syncLibraryFolderUI(); }
    for (const file of files) {
      if (!file.type.startsWith('audio/') && !/\.(mp3|m4a|flac|ogg|wav|aac|webm|aiff|opus)$/i.test(file.name)) continue;
      const folderRelativePath = String(file.webkitRelativePath || '').replace(/\\/g, '/');
      const sourceKey = `${folderRelativePath || file.name}|${file.size}|${file.lastModified}`;
      if (existing.has(sourceKey)) continue;
      showToast(`Analizando ${file.name}...`);
      const song=await readSongMetadata(file,sourceKey); additions.push(song); existing.add(sourceKey);
    }
    if(!additions.length){persistState();showToast(options.folderName ? 'La carpeta no contiene canciones nuevas compatibles.' : 'No se encontraron canciones nuevas.');return;}
    await writeSongs(additions); state.library.push(...additions); state.library.sort((a,b)=>(a.addedAt||0)-(b.addedAt||0)); state.queueIds=state.shuffle?[...state.queueIds,...shuffledIds(additions.map(s=>s.id))]:state.library.map(s=>s.id); if(!state.currentId){state.currentId=state.queueIds[0];state.queueIndex=0;await setCurrentTrack(state.currentId,{autoplay:false});} renderAll();persistState();showToast(`${additions.length} canción${additions.length===1?'':'es'} añadida${additions.length===1?'':'s'}${options.folderName ? ' desde la carpeta' : ''}.`);
  }
  function syncLibraryFolderUI() {
    if (!els.libraryFolderStatus) return;
    if (state.libraryFolderName) {
      const count = state.library.filter(song => String(song.sourceKey || '').startsWith(`${state.libraryFolderName}/`)).length;
      els.libraryFolderStatus.textContent = `Última carpeta: ${state.libraryFolderName}${count ? ` · ${count} canción(es) importadas desde ella` : ''}`;
    } else els.libraryFolderStatus.textContent = 'Todavía no has seleccionado una carpeta.';
  }
  async function readSongMetadata(file, sourceKey) {
    const metadata = await readTags(file);
    const title = cleanText(metadata.title) || file.name.replace(/\.[^.]+$/, '');
    const artist = cleanText(metadata.artist) || 'Artista desconocido';
    const album = cleanText(metadata.album) || 'Álbum desconocido';
    const genre = cleanText(metadata.genre) || 'Sin género';
    const rawTrack = metadata.track ?? metadata.tracknumber ?? metadata.trackNumber ?? '';
    const rawDisc = metadata.disc ?? metadata.discnumber ?? '';
    return {
      id: crypto.randomUUID(), sourceKey, name: file.name, mime: file.type || inferMime(file.name), size: file.size,
      addedAt: Date.now(), title, artist, album, genre,
      trackNumber: parseLeadingNumber(rawTrack), discNumber: parseLeadingNumber(rawDisc), year: cleanText(metadata.year),
      searchText: normalizeText(`${title} ${artist} ${album} ${genre} ${file.name}`), duration: null,
      coverBlob: pictureToBlob(metadata.picture), blob: file, lyrics: extractEmbeddedLyrics(metadata), externalPlainLyrics: '', externalSyncedLyrics: '',
      replayGainTrackDb: parseReplayGain(metadata.replaygain_track_gain), replayGainAlbumDb: parseReplayGain(metadata.replaygain_album_gain),
      favorite: false, playCount: 0, listenSeconds: 0, lastPlayed: 0
    };
  }
  function parseLeadingNumber(value) { const match = String(value ?? '').match(/^\s*(\d+)/); return match ? Number(match[1]) : 0; }
  function parseReplayGain(value){if(value==null)return null;const m=String(value).match(/[-+]?\d+(?:[.,]\d+)?/);return m?Number(m[0].replace(',','.')):null;}
  function readTags(file){return new Promise(resolve=>{if(!window.jsmediatags){resolve({});return;}try{new window.jsmediatags.Reader(file).setTagsToRead(JS_TAG_FIELDS).read({onSuccess:r=>resolve(r.tags||{}),onError:()=>resolve({})});}catch{resolve({});}});}
  function extractEmbeddedLyrics(metadata) {
    const candidates = [metadata?.lyrics, metadata?.unsyncedlyrics, metadata?.USLT, metadata?.unsynchronizedLyrics, metadata?.SYLT];
    for (const candidate of candidates) {
      const value = typeof candidate === 'string' ? candidate : candidate?.text || candidate?.lyrics || candidate?.data || candidate?.description;
      if (typeof value === 'string' && value.trim()) return value.trim();
    }
    return '';
  }
  function pictureToBlob(picture){if(!picture?.data?.length)return null;try{return new Blob([new Uint8Array(picture.data)],{type:picture.format||'image/jpeg'});}catch{return null;}}
  async function writeSongs(songs){await new Promise((resolve,reject)=>{const t=db.transaction(SONG_STORE,'readwrite');const s=t.objectStore(SONG_STORE);songs.forEach(song=>s.put(song));t.oncomplete=resolve;t.onerror=()=>reject(t.error);t.onabort=()=>reject(t.error);});}

  function renderAll() { renderLibrary(); renderQueue(); updateNowPlaying(); updateControls(); updateStats(); }
  function finishStartupIntro() {
    const intro = els.startupIntro;
    if (!intro) return;
    if (!state.startupAnimationEnabled) { intro.remove(); return; }
    intro.classList.add('intro-ready');
    setTimeout(() => {
      if (!intro.isConnected) return;
      intro.classList.add('is-exiting');
      const remove = () => intro.remove();
      intro.addEventListener('transitionend', remove, { once: true });
      setTimeout(remove, 850);
    }, 950);
  }
  function updateSeekFill(value) {
    const progress = clamp(Number(value) || 0, 0, 100);
    if (els.seekFill) els.seekFill.style.width = `${progress}%`;
    if (els.seekHead) els.seekHead.style.left = `${progress}%`;
    if (els.seekBar) els.seekBar.style.setProperty('--seek-progress', `${progress}%`);
  }
  function setPlayButtonState(playing) {
    if (!els.playBtn) return;
    els.playBtn.textContent = playing ? 'Ⅱ' : '▶';
    els.playBtn.setAttribute('aria-label', playing ? 'Pausar' : 'Reproducir');
    els.playBtn.title = playing ? 'Pausar' : 'Reproducir';
    els.playBtn.classList.toggle('is-playing', playing);
    document.querySelector('.player-card')?.classList.toggle('is-playing', playing);
  }
  function syncNowPlaylistButton() {
    const button = els.nowAddPlaylistBtn; if (!button) return;
    const online = Boolean(state.onlineCurrentTrack);
    const local = !online && Boolean(state.currentId && songById(state.currentId));
    button.disabled = !local && !online;
    button.title = online ? 'Las pistas online no se pueden guardar en playlists locales' : local ? 'Añadir canción a una playlist' : 'Selecciona una canción primero';
    button.setAttribute('aria-label', button.title);
  }
  function syncNowActionsButton() {
    const button = els.nowSongActionsBtn; if (!button) return;
    const local = !state.onlineCurrentTrack && Boolean(state.currentId && songById(state.currentId));
    button.disabled = !local; button.title = local ? 'Acciones de la canción' : 'Las acciones de edición están disponibles para música local';
    button.setAttribute('aria-label', button.title);
    if (els.nowLyricsBtn) { els.nowLyricsBtn.disabled = !state.onlineCurrentTrack && !local; els.nowLyricsBtn.title = local || state.onlineCurrentTrack ? 'Mostrar letras de la canción' : 'Selecciona una canción para ver las letras'; }
  }
  function filteredLibrary() {
    let songs = [...state.library];
    let scored = null;
    if (state.query) {
      scored = new Map();
      songs = songs.filter(song => { const score = smartSearchScore(song, state.query); if (score <= 0) return false; scored.set(song.id, score); return true; });
    }
    if (state.view === 'favorites') songs = songs.filter(song => song.favorite);
    if (state.view === 'recent') { const rank = new Map(); state.history.forEach((item, i) => { if (!rank.has(item.songId)) rank.set(item.songId, i); }); songs = songs.filter(song => rank.has(song.id)).sort((a, b) => rank.get(a.id) - rank.get(b.id)); }
    if (state.view === 'most') songs = songs.filter(song => song.playCount > 0).sort((a, b) => (b.playCount || 0) - (a.playCount || 0));
    if (scored) songs.sort((a, b) => scored.get(b.id) - scored.get(a.id));
    return songs;
  }
  function smartSearchScore(song, query) {
    const tokens = normalizeText(query).split(/\s+/).filter(Boolean);
    if (!tokens.length) return 1;
    const fields = [
      { value: normalizeText(song.title), weight: 5 },
      { value: normalizeText(song.artist), weight: 4 },
      { value: normalizeText(song.album), weight: 3 },
      { value: normalizeText(song.genre), weight: 2 },
      { value: normalizeText(song.name), weight: 1.5 }
    ].filter(field => field.value);
    let total = 0;
    for (const token of tokens) {
      let best = 0;
      for (const field of fields) {
        const value = field.value;
        let score = 0;
        if (value === token) score = 32;
        else if (value.startsWith(token)) score = 24;
        else if (value.includes(token)) score = 16;
        const words = value.split(/[^a-z0-9]+/).filter(Boolean);
        for (const word of words) {
          if (word === token) score = Math.max(score, 30);
          else if (word.startsWith(token)) score = Math.max(score, 23);
          else if (token.length >= 4) {
            const distance = editDistanceAtMostTwo(word, token);
            if (distance === 1) score = Math.max(score, 13);
            else if (distance === 2 && token.length >= 7) score = Math.max(score, 6);
          }
        }
        best = Math.max(best, score * field.weight);
      }
      if (best <= 0) return 0;
      total += best;
    }
    return total / tokens.length;
  }
  function editDistanceAtMostTwo(a, b) {
    if (Math.abs(a.length - b.length) > 2) return 3;
    if (a === b) return 0;
    let previous = Array.from({length: b.length + 1}, (_, i) => i);
    for (let i = 1; i <= a.length; i++) {
      const current = [i]; let rowMin = i;
      for (let j = 1; j <= b.length; j++) {
        current[j] = Math.min(current[j - 1] + 1, previous[j] + 1, previous[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
        rowMin = Math.min(rowMin, current[j]);
      }
      if (rowMin > 2) return 3;
      previous = current;
    }
    return previous[b.length];
  }
  function setToolbarActions(html) { if (els.libraryToolbarActions) els.libraryToolbarActions.innerHTML = html || ''; }
  function renderLibrary() {
    if (state.view === 'online') { setToolbarActions(''); renderOnlineHome(); return; }
    const descriptions = { songs: 'Toda tu música local', favorites: 'Canciones que marcaste con ❤️', playlists: 'Tus listas personalizadas', recent: 'Lo último que escuchaste', most: 'Tus canciones más reproducidas', recommendations: 'Selección personalizada según tus hábitos de escucha', albums: 'Álbumes detectados en tu biblioteca', artists: 'Artistas de tu biblioteca' };
    const titles = { songs: 'Canciones', favorites: 'Favoritas', playlists: 'Playlists', recent: 'Recientes', most: 'Más reproducidas', recommendations: 'Para ti', albums: 'Álbumes', artists: 'Artistas' };
    els.sectionTitle.textContent = titles[state.view] || 'Biblioteca';
    els.viewDescription.textContent = descriptions[state.view] || '';
    if (state.view === 'recommendations') { setToolbarActions(''); renderRecommendations(); return; }
    if (state.view === 'playlists') {
      if (state.playlistDetailId && state.playlists.some(item => item.id === state.playlistDetailId)) {
        setToolbarActions('<button class="secondary-btn toolbar-create-btn" id="playlistBackBtn" type="button">← Todas las playlists</button>');
        document.getElementById('playlistBackBtn')?.addEventListener('click', () => { state.playlistDetailId = null; renderLibrary(); });
        renderPlaylistDetail(state.playlistDetailId); return;
      }
      state.playlistDetailId = null;
      setToolbarActions('<button class="secondary-btn toolbar-create-btn" id="playlistCreateInView" type="button">＋ Nueva playlist</button>');
      document.getElementById('playlistCreateInView')?.addEventListener('click', () => openPlaylistModal());
      renderPlaylists(); return;
    }
    state.playlistDetailId = null;
    if (state.view === 'albums' && state.albumDetail) {
      setToolbarActions('<button class="secondary-btn toolbar-create-btn" id="albumBackBtn" type="button">← Todos los álbumes</button>');
      document.getElementById('albumBackBtn')?.addEventListener('click', () => { state.albumDetail = null; renderLibrary(); });
      renderAlbumDetail(); return;
    }
    if (state.view === 'artists' && state.artistDetail) {
      setToolbarActions('<button class="secondary-btn toolbar-create-btn" id="artistBackBtn" type="button">← Todos los artistas</button>');
      document.getElementById('artistBackBtn')?.addEventListener('click', () => { state.artistDetail = null; renderLibrary(); });
      renderArtistDetail(state.artistDetail); return;
    }
    setToolbarActions('');
    const songs = filteredLibrary();
    if (!songs.length) { els.libraryBody.innerHTML = emptyStateHTML(state.library.length ? 'Sin resultados' : 'Tu biblioteca está vacía', state.library.length ? 'Prueba otra búsqueda.' : 'Añade tus archivos de audio para comenzar.'); return; }
    if (state.view === 'albums') renderAlbums(songs);
    else if (state.view === 'artists') renderArtists(songs);
    else renderSongs(songs);
  }
  function buildRecommendations() {
    const songs = [...state.library];
    if (!songs.length) return [];
    const artistAffinity = new Map(), genreAffinity = new Map();
    for (const song of songs) {
      const base = (Number(song.playCount) || 0) * 2 + (Number(song.listenSeconds) || 0) / 180 + (song.favorite ? 2 : 0);
      const artist = normalizeText(song.artist || 'Artista desconocido');
      const genre = normalizeText(song.genre || 'Sin género');
      artistAffinity.set(artist, (artistAffinity.get(artist) || 0) + base);
      genreAffinity.set(genre, (genreAffinity.get(genre) || 0) + base * .45);
    }
    const now = Date.now();
    const songItems = songs.map(song => {
      const ageDays = song.lastPlayed ? (now - Number(song.lastPlayed)) / 86400000 : 999;
      const recency = song.lastPlayed ? Math.max(0, 2 - ageDays / 5) : 0;
      const score = (Number(song.playCount) || 0) * 2.25 + (Number(song.listenSeconds) || 0) / 170 + (song.favorite ? 2.2 : 0) + recency + (artistAffinity.get(normalizeText(song.artist)) || 0) * .12 + (genreAffinity.get(normalizeText(song.genre)) || 0) * .1;
      return { type: 'song', id: song.id, song, title: song.title, subtitle: song.artist, cover: coverSrc(song), score };
    }).sort((a,b)=>b.score-a.score);
    const groups = new Map();
    songs.forEach(song => {
      const album = cleanText(song.album) || 'Álbum desconocido';
      const artist = cleanText(song.artist) || 'Artista desconocido';
      const key = `${normalizeText(album)}::${normalizeText(artist)}`;
      if (!groups.has(key)) groups.set(key, {type:'album', id:song.id, album, artist, songs:[], coverSong:song, score:0, lastPlayed:0});
      const group = groups.get(key); group.songs.push(song);
      const listened = Number(song.listenSeconds) || 0;
      group.score += (Number(song.playCount)||0) * 1.45 + listened / 340 + (song.favorite ? .7 : 0);
      group.lastPlayed = Math.max(group.lastPlayed, Number(song.lastPlayed)||0);
      if (!group.coverSong.coverBlob && song.coverBlob) group.coverSong = song;
    });
    const albumItems = [...groups.values()].map(group => {
      const ageDays = group.lastPlayed ? (now-group.lastPlayed)/86400000 : 999;
      const recency = group.lastPlayed ? Math.max(0, 1.5-ageDays/6) : 0;
      group.score += Math.min(group.songs.length, 8) * .5 + recency;
      return { type:'album', id:group.id, album:group.album, artist:group.artist, songIds:group.songs.map(song=>song.id), song:group.coverSong, title:group.album, subtitle:`${group.artist} · ${group.songs.length} canción${group.songs.length===1?'':'es'}`, cover:coverSrc(group.coverSong), score:group.score };
    }).sort((a,b)=>b.score-a.score);
    // Interleave tracks and albums so the page recommends both kinds of content.
    const result=[]; const topSongs=songItems.slice(0,8); const topAlbums=albumItems.slice(0,8);
    for(let i=0;i<Math.max(topSongs.length,topAlbums.length);i++) { if(topSongs[i]) result.push(topSongs[i]); if(topAlbums[i]) result.push(topAlbums[i]); }
    return result.slice(0,16);
  }
  function renderRecommendations({ animateDirection = 'next' } = {}) {
    if (state.query) {
      const matches = filteredLibrary();
      els.viewDescription.textContent = `Resultados relacionados con “${els.librarySearch.value.trim()}”`;
      els.libraryBody.innerHTML = matches.length ? trackRowsHTML(matches) : emptyStateHTML('No hay coincidencias', 'Prueba con otro título, artista o álbum.');
      if (matches.length) bindTrackRows();
      return;
    }
    if (!state.library.length) { els.libraryBody.innerHTML = emptyStateHTML('Todavía no hay recomendaciones', 'Añade música y reproduce tus canciones. ẞetaMusic usará tus reproducciones y el tiempo de escucha para preparar una selección personal.'); return; }
    const items = buildRecommendations();
    const pageSize = 4; const pageCount = Math.max(1, Math.ceil(items.length / pageSize));
    state.recommendationPage = ((Number(state.recommendationPage)||0) % pageCount + pageCount) % pageCount;
    const start = state.recommendationPage * pageSize;
    const pageItems = items.slice(start,start+pageSize);
    const cards = pageItems.map(item => {
      const cover = item.cover ? `<img class="recommendation-cover" src="${escapeAttr(item.cover)}" alt="">` : '<div class="recommendation-cover recommendation-cover-fallback">♫</div>';
      const type = item.type === 'album' ? 'ÁLBUM RECOMENDADO' : 'PARA VOLVER A ESCUCHAR';
      const hint = item.type === 'album' ? 'Abrir álbum ↗' : 'Reproducir ahora ▶';
      return `<article class="recommendation-card" role="button" tabindex="0" data-rec-type="${item.type}" data-rec-id="${escapeAttr(item.id)}" title="${item.type==='album'?'Ver álbum':'Reproducir canción'}">${cover}<div class="recommendation-copy"><span class="recommendation-type">${type}</span><strong>${escapeHTML(item.title)}</strong><span>${escapeHTML(item.subtitle)}</span><div class="recommendation-hint">${hint}</div></div></article>`;
    }).join('');
    const dotButtons = Array.from({length:pageCount},(_,i)=>`<button class="recommendation-dot ${i===state.recommendationPage?'active':''}" type="button" data-rec-page="${i}" aria-label="Página ${i+1}" aria-current="${i===state.recommendationPage?'page':'false'}"></button>`).join('');
    els.libraryBody.innerHTML = `<section class="recommendation-stage"><header class="recommendation-header"><div class="recommendation-heading"><span class="recommendation-kicker">TU AURORA MUSICAL · HOY</span><h3>Tus recomendaciones para hoy</h3><p>Una selección que aprende de tus canciones, álbumes y tiempo de escucha. Todo se calcula localmente a partir de tu biblioteca.</p></div><span class="recommendation-count">${items.length} selecciones</span></header><div class="recommendation-book"><div class="recommendation-page ${animateDirection==='back'?'flip-back':''}">${cards}</div></div><nav class="recommendation-controls" aria-label="Páginas de recomendaciones"><button type="button" data-rec-prev ${state.recommendationPage===0?'disabled':''}>← Anterior</button><div class="recommendation-dots">${dotButtons}</div><button type="button" data-rec-next ${state.recommendationPage>=pageCount-1?'disabled':''}>Siguiente →</button></nav><p class="recommendation-note">Las recomendaciones mejoran a medida que escuchas canciones completas. No se envía tu historial a un servidor.</p></section>`;
    const flip = direction => { if (direction==='back' && state.recommendationPage>0) state.recommendationPage--; else if (direction==='next' && state.recommendationPage<pageCount-1) state.recommendationPage++; else return; persistState(); renderRecommendations({animateDirection:direction}); };
    els.libraryBody.querySelector('[data-rec-prev]')?.addEventListener('click',()=>flip('back'));
    els.libraryBody.querySelector('[data-rec-next]')?.addEventListener('click',()=>flip('next'));
    els.libraryBody.querySelectorAll('[data-rec-page]').forEach(button=>button.addEventListener('click',()=>{const target=Number(button.dataset.recPage);if(target===state.recommendationPage)return;state.recommendationPage=target;persistState();renderRecommendations({animateDirection:target<start/pageSize?'back':'next'});}));
    els.libraryBody.querySelectorAll('[data-rec-type]').forEach(card=>{
      const activate=()=>{const item=items.find(entry=>entry.id===card.dataset.recId&&entry.type===card.dataset.recType);if(!item)return;if(item.type==='album')openAlbumDetail(item.song);else playById(item.id);};
      card.addEventListener('click',activate);card.addEventListener('keydown',event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();activate();}});
    });
  }

  function trackRowsHTML(songs, extraClass = '', forceList = false) {
    return `<div class="song-list ${!forceList && state.libraryViewMode === 'grid' ? 'song-grid-view' : ''} ${extraClass}">${songs.map((song, index) => {
      const playing = song.id === state.currentId; const cover = coverSrc(song);
      const rating = '★'.repeat(song.rating || 0) + '☆'.repeat(5 - (song.rating || 0));
      return `<div class="track-row ${playing ? 'playing' : ''}" data-id="${escapeAttr(song.id)}"><div class="track-index">${playing ? '●' : String(index + 1).padStart(2, '0')}</div><div class="track-main">${cover ? `<img class="row-cover" src="${cover}" alt="">` : '<div class="row-cover"></div>'}<div class="track-text"><div class="track-title">${escapeHTML(song.title)}</div><div class="track-sub">${escapeHTML(song.artist)} <span class="row-rating">${rating}</span></div></div></div><div class="track-cell track-album">${escapeHTML(song.album)}</div><div class="track-cell track-format">${escapeHTML(extensionOf(song.name).toUpperCase())}</div><button class="track-like ${song.favorite ? 'active' : ''}" data-fav="${escapeAttr(song.id)}" title="Favorito">${song.favorite ? '♥' : '♡'}</button><button class="row-menu" data-menu="${escapeAttr(song.id)}" type="button" aria-label="Acciones de ${escapeAttr(song.title)}">⋯</button><div class="track-cell track-duration">${formatTime(song.duration)}</div></div>`;
    }).join('')}</div>`;
  }
  function bindTrackRows(root = els.libraryBody, playHandler = playById) {
    root.querySelectorAll('.track-row').forEach(row => row.addEventListener('click', event => { if (event.target.closest('[data-fav],[data-menu]')) return; playHandler(row.dataset.id); }));
    root.querySelectorAll('[data-fav]').forEach(button => button.addEventListener('click', event => { event.stopPropagation(); toggleFavorite(button.dataset.fav); }));
    root.querySelectorAll('[data-menu]').forEach(button => button.addEventListener('click', event => { event.stopPropagation(); showSongActions(button.dataset.menu); }));
  }
  function renderSongs(songs) { els.libraryBody.innerHTML = trackRowsHTML(songs); bindTrackRows(); }
  function renderPlaylists() {
    const query = state.query;
    const lists = state.playlists.filter(playlist => !query || normalizeText(playlist.name).includes(query));
    els.libraryBody.innerHTML = lists.length ? `<div class="playlist-grid">${lists.map(playlist => {
      const ids = Array.isArray(playlist.songIds) ? playlist.songIds : [];
      const song = ids.map(songById).find(Boolean); const cover = song?.coverBlob ? coverSrc(song) : '';
      return `<article class="playlist-card" data-playlist="${escapeAttr(playlist.id)}"><div class="playlist-cover">${cover ? `<img src="${cover}" alt="">` : '♫'}</div><strong>${escapeHTML(playlist.name)}</strong><span>${ids.length} canción${ids.length === 1 ? '' : 'es'}</span><div class="playlist-card-actions"><button data-play-playlist="${escapeAttr(playlist.id)}" type="button" title="Reproducir">▶</button><button data-delete-playlist="${escapeAttr(playlist.id)}" type="button">Eliminar</button></div></article>`;
    }).join('')}</div>` : `<div class="empty-state playlist-empty"><div><div class="empty-icon">♫</div><h3>No tienes playlists todavía</h3><p>Crea una lista para organizar tu música.</p><button class="primary-btn" id="emptyCreatePlaylist" type="button">＋ Crear playlist</button></div></div>`;
    document.getElementById('emptyCreatePlaylist')?.addEventListener('click', () => openPlaylistModal());
    els.libraryBody.querySelectorAll('[data-play-playlist]').forEach(button => button.addEventListener('click', event => { event.stopPropagation(); playPlaylist(button.dataset.playPlaylist); }));
    els.libraryBody.querySelectorAll('[data-delete-playlist]').forEach(button => button.addEventListener('click', event => { event.stopPropagation(); deletePlaylist(button.dataset.deletePlaylist); }));
    els.libraryBody.querySelectorAll('.playlist-card').forEach(card => card.addEventListener('click', () => showPlaylist(card.dataset.playlist)));
  }
  function showPlaylist(id) { if (!state.playlists.some(playlist => playlist.id === id)) return; state.playlistDetailId = id; state.query = ''; els.librarySearch.value = ''; renderLibrary(); }
  function renderPlaylistDetail(id) {
    const playlist = state.playlists.find(item => item.id === id); if (!playlist) return;
    const songs = (Array.isArray(playlist.songIds) ? playlist.songIds : []).map(songById).filter(Boolean);
    els.sectionTitle.textContent = playlist.name; els.viewDescription.textContent = `${songs.length} de ${playlist.songIds.length} canciones disponibles`;
    const representative = songs.find(song => song.coverBlob);
    els.libraryBody.innerHTML = `<section class="collection-detail"><div class="collection-detail-art">${representative ? `<img src="${coverSrc(representative)}" alt="">` : '♫'}</div><div class="collection-detail-info"><span class="eyebrow">PLAYLIST</span><h3>${escapeHTML(playlist.name)}</h3><p>${songs.length} canciones · lista personal</p><button class="primary-btn" id="playPlaylistDetail" type="button" ${songs.length ? '' : 'disabled'}>▶ Reproducir lista</button></div></section>${songs.length ? trackRowsHTML(songs, 'collection-track-list') : '<div class="empty-state"><div><h3>Esta playlist está vacía</h3><p>Añade canciones con el botón ＋ del reproductor o desde las acciones de cada pista.</p></div></div>'}`;
    document.getElementById('playPlaylistDetail')?.addEventListener('click', () => playPlaylist(id)); bindTrackRows(els.libraryBody, songId => playPlaylistTrack(id, songId));
  }
  function sortAlbumSongs(songs) {
    return [...songs].sort((a, b) => {
      const ad = Number(a.discNumber) || 1, bd = Number(b.discNumber) || 1;
      if (ad !== bd) return ad - bd;
      const at = Number(a.trackNumber) || 0, bt = Number(b.trackNumber) || 0;
      if (at && bt && at !== bt) return at - bt;
      if (at && !bt) return -1; if (bt && !at) return 1;
      return (a.addedAt || 0) - (b.addedAt || 0) || a.title.localeCompare(b.title, undefined, { numeric: true, sensitivity: 'base' });
    });
  }
  function renderAlbums(songs) {
    const albums = new Map();
    songs.forEach(song => {
      const key = `${song.album}\0${song.artist}`;
      if (!albums.has(key)) albums.set(key, { album: song.album || 'Álbum desconocido', artist: song.artist || 'Artista desconocido', songs: [], cover: song.coverBlob ? song : null });
      const group = albums.get(key); group.songs.push(song); if (!group.cover && song.coverBlob) group.cover = song;
    });
    const groups = [...albums.values()].sort((a, b) => a.album.localeCompare(b.album, undefined, { sensitivity: 'base' }));
    els.libraryBody.innerHTML = `<div class="album-grid">${groups.map(album => {
      const cover = album.cover ? coverSrc(album.cover) : '';
      return `<article class="album-card" data-album="${escapeAttr(album.album)}" data-artist="${escapeAttr(album.artist)}">${cover ? `<img class="album-cover" src="${cover}" alt="">` : '<div class="album-cover"></div>'}<strong>${escapeHTML(album.album)}</strong><span>${escapeHTML(album.artist)} · ${album.songs.length} temas</span></article>`;
    }).join('')}</div>`;
    els.libraryBody.querySelectorAll('.album-card').forEach(card => card.addEventListener('click', () => {
      state.albumDetail = { album: card.dataset.album, artist: card.dataset.artist };
      state.query = ''; els.librarySearch.value = ''; renderLibrary();
    }));
  }
  function renderAlbumDetail() {
    const detail = state.albumDetail; if (!detail) return;
    const songs = sortAlbumSongs(state.library.filter(song => song.album === detail.album && song.artist === detail.artist));
    if (!songs.length) { state.albumDetail = null; renderLibrary(); return; }
    const coverSong = songs.find(song => song.coverBlob) || songs[0];
    const cover = coverSong?.coverBlob ? coverSrc(coverSong) : '';
    const totalSeconds = songs.reduce((sum, song) => sum + (Number(song.duration) || 0), 0);
    els.sectionTitle.textContent = detail.album; els.viewDescription.textContent = `${detail.artist} · ${songs.length} canciones`;
    els.libraryBody.innerHTML = `<section class="collection-detail album-detail-hero"><div class="collection-detail-art">${cover ? `<img src="${cover}" alt="">` : '♫'}</div><div class="collection-detail-info"><span class="eyebrow">ÁLBUM</span><h3>${escapeHTML(detail.album)}</h3><p>${escapeHTML(detail.artist)} · ${songs.length} canciones${totalSeconds ? ` · ${formatTime(totalSeconds)}` : ''}${songs.some(song => song.year) ? ` · ${escapeHTML(songs.find(song => song.year)?.year || '')}` : ''}</p><button class="primary-btn" id="playAlbumDetail" type="button">▶ Reproducir álbum</button></div></section><div class="album-track-heading"><span>N.º</span><span>CANCIÓN</span><span>ÁLBUM</span><span>TIPO</span><span>FAV.</span><span></span><span>DURACIÓN</span></div>${trackRowsHTML(songs, 'collection-track-list', true)}`;
    document.getElementById('playAlbumDetail')?.addEventListener('click', () => playAlbum(detail.album, detail.artist)); bindTrackRows(els.libraryBody, songId => playAlbumTrack(detail.album, detail.artist, songId));
  }
  async function playAlbumTrack(album, artist, songId) {
    const songs = sortAlbumSongs(state.library.filter(song => song.album === album && song.artist === artist));
    const ids = songs.map(song => song.id); if (!ids.includes(songId)) return;
    state.queueIds = ids; state.queueIndex = ids.indexOf(songId); state.shuffle = false; updateControls();
    await setCurrentTrack(songId, { autoplay: true }); persistState(); renderQueue();
  }
  async function playAlbum(album, artist) {
    const songs = sortAlbumSongs(state.library.filter(song => song.album === album && song.artist === artist));
    if (!songs.length) return;
    state.queueIds = songs.map(song => song.id); state.queueIndex = 0; state.shuffle = false; updateControls();
    await setCurrentTrack(songs[0].id, { autoplay: true }); persistState(); renderQueue();
  }
  function renderArtists(songs) {
    const artists = new Map(); songs.forEach(song => { if (!artists.has(song.artist)) artists.set(song.artist, []); artists.get(song.artist).push(song); });
    els.libraryBody.innerHTML = `<div class="artist-grid">${[...artists.entries()].sort((a, b) => a[0].localeCompare(b[0])).map(([artist, list]) => `<article class="artist-card" data-artist="${escapeAttr(artist)}"><div class="artist-avatar">${escapeHTML((artist[0] || '?').toUpperCase())}</div><strong>${escapeHTML(artist)}</strong><span>${list.length} temas</span></article>`).join('')}</div>`;
    els.libraryBody.querySelectorAll('.artist-card').forEach(card => card.addEventListener('click', () => openArtistDetail(card.dataset.artist)));
  }
  function sortArtistSongs(artist) {
    return state.library.filter(song => song.artist === artist).sort((a, b) => {
      const albumOrder = (a.album || '').localeCompare(b.album || '', undefined, { numeric: true, sensitivity: 'base' });
      if (albumOrder) return albumOrder;
      return sortAlbumSongs([a, b]).indexOf(a) - sortAlbumSongs([a, b]).indexOf(b);
    });
  }
  function openAlbumDetail(song) {
    if (!song) return;
    state.view = 'albums'; state.albumDetail = { album: song.album || 'Álbum desconocido', artist: song.artist || 'Artista desconocido' };
    state.artistDetail = null; state.playlistDetailId = null; state.query = ''; els.librarySearch.value = '';
    syncViewTabs(); renderLibrary(); persistState();
  }
  function openArtistDetail(artist) {
    if (!artist) return;
    state.view = 'artists'; state.artistDetail = artist; state.albumDetail = null; state.playlistDetailId = null;
    state.query = ''; els.librarySearch.value = ''; syncViewTabs(); renderLibrary(); persistState();
  }
  function renderArtistDetail(artist) {
    const songs = sortArtistSongs(artist);
    if (!songs.length) { state.artistDetail = null; renderLibrary(); return; }
    const coverSong = songs.find(song => song.coverBlob) || songs[0];
    const cover = coverSong?.coverBlob ? coverSrc(coverSong) : '';
    const albums = new Set(songs.map(song => song.album || 'Álbum desconocido'));
    const totalSeconds = songs.reduce((sum, song) => sum + (Number(song.duration) || 0), 0);
    els.sectionTitle.textContent = artist; els.viewDescription.textContent = `${songs.length} canciones · ${albums.size} álbum${albums.size === 1 ? '' : 'es'}`;
    els.libraryBody.innerHTML = `<section class="collection-detail artist-detail-hero"><div class="collection-detail-art">${cover ? `<img src="${cover}" alt="">` : '♫'}</div><div class="collection-detail-info"><span class="eyebrow">ARTISTA</span><h3>${escapeHTML(artist)}</h3><p>${songs.length} canciones · ${albums.size} álbum${albums.size === 1 ? '' : 'es'}${totalSeconds ? ` · ${formatTime(totalSeconds)}` : ''}</p><button class="primary-btn" id="playArtistDetail" type="button">▶ Reproducir artista</button></div></section><div class="album-track-heading"><span>N.º</span><span>CANCIÓN</span><span>ÁLBUM</span><span>TIPO</span><span>FAV.</span><span></span><span>DURACIÓN</span></div>${trackRowsHTML(songs, 'collection-track-list', true)}`;
    document.getElementById('playArtistDetail')?.addEventListener('click', () => playArtist(artist));
    bindTrackRows(els.libraryBody, songId => playArtistTrack(artist, songId));
  }
  async function playArtist(artist) {
    const songs = sortArtistSongs(artist); if (!songs.length) return;
    state.queueIds = songs.map(song => song.id); state.queueIndex = 0; state.shuffle = false; updateControls();
    await setCurrentTrack(songs[0].id, { autoplay: true }); persistState(); renderQueue();
  }
  async function playArtistTrack(artist, songId) {
    const ids = sortArtistSongs(artist).map(song => song.id); if (!ids.includes(songId)) return;
    state.queueIds = ids; state.queueIndex = ids.indexOf(songId); state.shuffle = false; updateControls();
    await setCurrentTrack(songId, { autoplay: true }); persistState(); renderQueue();
  }

  function closeLyrics() { if (!els.lyricsOverlay) return; els.lyricsOverlay.classList.remove('open'); els.lyricsOverlay.setAttribute('aria-hidden','true'); }
  function lyricTextValue(value) { return typeof value === 'string' ? value.trim() : ''; }
  function lyricsLinesMarkup(text, synced = false) {
    const lines = [];
    for (const rawLine of String(text || '').split(/\r?\n/)) {
      const trimmed = rawLine.trim();
      if (!trimmed) continue;
      if (synced) {
        const times = [...trimmed.matchAll(/\[(\d{1,2}):(\d{2})(?:[.:](\d{1,3}))?\]/g)];
        const lyric = trimmed.replace(/(?:\[\d{1,2}:\d{2}(?:[.:]\d{1,3})?\])+\s*/g,'').trim();
        if (!lyric) continue;
        if (times.length) for (const match of times) { const fraction = String(match[3] || '0'); const seconds = Number(match[1])*60 + Number(match[2]) + Number((fraction+'00').slice(0,3))/1000; lines.push({text:lyric,time:seconds}); }
        else lines.push({text:trimmed,time:null});
      } else lines.push({text:trimmed,time:null});
    }
    if (!lines.length) return '<div class="lyrics-empty"><div><strong>No se encontraron letras</strong><p>Esta canción no contiene letras incrustadas y no se pudo encontrar una versión en línea.</p></div></div>';
    return `<div class="lyrics-lines" data-synced="${synced?'true':'false'}">${lines.map(line=>line.time===null?`<div class="lyric-line">${escapeHTML(line.text)}</div>`:`<button class="lyric-line" type="button" data-lyric-time="${line.time.toFixed(3)}">${escapeHTML(line.text)}</button>`).join('')}</div>`;
  }
  function updateLyricsHighlight() {
    const linesRoot = els.lyricsContent?.querySelector('.lyrics-lines[data-synced="true"]');
    if (!linesRoot) return;
    const current = Number(els.audio.currentTime)||0;
    let active = null;
    linesRoot.querySelectorAll('[data-lyric-time]').forEach(line => {
      const time = Number(line.dataset.lyricTime);
      const isCurrent = time <= current;
      line.classList.toggle('active',isCurrent && (!active || time >= Number(active.dataset.lyricTime)));
      if (isCurrent && (!active || time >= Number(active.dataset.lyricTime))) active = line;
    });
    if (active && !document.hidden && !els.lyricsContent.contains(document.activeElement)) {
      linesRoot.querySelectorAll('.lyric-line.active').forEach(line=>{ if(line!==active)line.classList.remove('active'); });
      if (active.dataset.lastScrolled !== 'true') { active.scrollIntoView({block:'nearest',behavior:state.animationsEnabled?'smooth':'auto'}); active.dataset.lastScrolled='true'; }
    }
  }
  function displayLyrics(text, synced, source) {
    els.lyricsContent.innerHTML = lyricsLinesMarkup(text,synced);
    els.lyricsSource.textContent = source || 'Letras disponibles';
    els.lyricsContent.querySelectorAll('[data-lyric-time]').forEach(line=>line.addEventListener('click',()=>{const time=Number(line.dataset.lyricTime);if(Number.isFinite(time)&&Number.isFinite(els.audio.duration))els.audio.currentTime=Math.min(time,els.audio.duration);}));
    updateLyricsHighlight();
  }
  async function findOnlineLyrics(track) {
    if (!window.auroOnline?.fetchJson) throw new Error('La búsqueda de letras requiere la conexión online.');
    const params = new URLSearchParams();
    params.set('track_name',String(track.title || track.name || '').trim());
    params.set('artist_name',String(track.artist || track.artist_name || '').trim());
    if (track.album || track.album_name) params.set('album_name',String(track.album || track.album_name).trim());
    const duration = Number(track.duration);
    if (Number.isFinite(duration) && duration > 1 && duration <= 3600) params.set('duration',String(Math.round(duration)));
    if (!params.get('track_name') || !params.get('artist_name')) throw new Error('Faltan el título o el artista para buscar letras.');
    try {
      const exact = await window.auroOnline.fetchJson(`https://lrclib.net/api/get?${params.toString()}`);
      if (exact && (exact.plainLyrics || exact.syncedLyrics)) return exact;
    } catch {}
    const searchParams = new URLSearchParams({track_name:params.get('track_name'),artist_name:params.get('artist_name')});
    if (params.has('album_name')) searchParams.set('album_name',params.get('album_name'));
    const results = await window.auroOnline.fetchJson(`https://lrclib.net/api/search?${searchParams.toString()}`);
    if (!Array.isArray(results)) throw new Error('Respuesta de letras no válida.');
    const titleKey = normalizeText(params.get('track_name')), artistKey = normalizeText(params.get('artist_name'));
    const ranked = results.filter(item=>item && (item.plainLyrics || item.syncedLyrics) && !item.instrumental).sort((a,b)=>{
      const score = item => (normalizeText(item.trackName||item.name)===titleKey?4:normalizeText(item.trackName||item.name).includes(titleKey)?2:0)+(normalizeText(item.artistName||'')===artistKey?4:normalizeText(item.artistName||'').includes(artistKey)?2:0)+(params.has('album_name')&&normalizeText(item.albumName||'')===normalizeText(params.get('album_name'))?1:0);
      return score(b)-score(a);
    });
    if (!ranked.length) throw new Error('No se encontraron letras para esta canción.');
    return ranked[0];
  }
  async function openLyrics(forceOnline = false) {
    const localSong = state.currentId ? songById(state.currentId) : null;
    const online = state.onlineCurrentTrack;
    if (!localSong && !online) { showToast('Selecciona una canción para ver sus letras.'); return; }
    const token = ++lyricsRequestToken;
    els.lyricsOverlay.classList.add('open'); els.lyricsOverlay.setAttribute('aria-hidden','false');
    const title = localSong?.title || online?.name || 'Canción';
    const artist = localSong?.artist || online?.artist_name || 'Artista desconocido';
    els.lyricsTitle.textContent = title;
    els.lyricsSubtitle.textContent = `${artist}${localSong?.album ? ` · ${localSong.album}` : (online?.album_name ? ` · ${online.album_name}` : '')}`;
    const embedded = localSong ? lyricTextValue(localSong.lyrics) : '';
    const externalPlain = localSong ? lyricTextValue(localSong.externalPlainLyrics) : '';
    const externalSynced = localSong ? lyricTextValue(localSong.externalSyncedLyrics) : '';
    if (!forceOnline && embedded) { displayLyrics(embedded,/^\s*\[\d{1,2}:\d{2}(?:[.:]\d{1,3})?\]/m.test(embedded),'Letras incrustadas en el archivo de audio'); return; }
    if (!forceOnline && (externalPlain || externalSynced)) { displayLyrics(externalSynced || externalPlain,Boolean(externalSynced),'Letras proporcionadas por LRCLIB'); return; }
    els.lyricsContent.innerHTML = '<div class="lyrics-loading">♫<span>Buscando letras para esta canción…</span></div>';
    els.lyricsSource.textContent = 'Consultando un catálogo de letras online.';
    try {
      const result = await findOnlineLyrics({title,artist,album:localSong?.album||online?.album_name||'',duration:Number(els.audio.duration)||Number(localSong?.duration)||0});
      if (token !== lyricsRequestToken || !els.lyricsOverlay.classList.contains('open')) return;
      const synced = lyricTextValue(result.syncedLyrics), plain = lyricTextValue(result.plainLyrics);
      if (!synced && !plain) throw new Error('El catálogo no contiene letras para esta canción.');
      if (localSong) {
        localSong.externalPlainLyrics=plain; localSong.externalSyncedLyrics=synced;
        idbRequest(tx(SONG_STORE,'readwrite').put(localSong)).catch(console.error);
      }
      displayLyrics(synced||plain,Boolean(synced),'Letras proporcionadas por LRCLIB');
    } catch (error) {
      if (token !== lyricsRequestToken) return;
      els.lyricsContent.innerHTML = `<div class="lyrics-empty"><div><strong>No se encontraron letras</strong><p>${escapeHTML(String(error?.message || 'No se pudo conectar con el catálogo.'))}</p><p>Comprueba la conexión a Internet o usa un archivo que tenga letras incrustadas.</p></div></div>`;
      els.lyricsSource.textContent = 'La búsqueda online no encontró una coincidencia.';
    }
  }

  function renderQueue(){const tracks=state.queueIds.map(songById).filter(Boolean);els.queueCount.textContent=String(tracks.length);els.queueList.innerHTML=tracks.length?tracks.map((song,index)=>`<div class="queue-item ${song.id===state.currentId?'active':''}" data-id="${escapeAttr(song.id)}">${coverSrc(song)?`<img class="queue-cover" src="${coverSrc(song)}" alt="">`:'<div class="queue-cover"></div>'}<div class="queue-title"><strong>${escapeHTML(song.title)}</strong><span>${escapeHTML(song.artist)}</span></div><span class="queue-number">${index+1}</span></div>`).join(''):'<div class="empty-state" style="min-height:180px"><div><div class="empty-icon">☷</div><p>La cola está vacía.</p></div></div>';els.queueList.querySelectorAll('.queue-item').forEach(item=>item.addEventListener('click',()=>playById(item.dataset.id)));}
  function updateNowPlaying(){
    syncNowPlaylistButton(); syncNowActionsButton();
    if(state.onlineCurrentTrack){ const t=state.onlineCurrentTrack; els.nowTitle.textContent=t.name||'Canción online'; els.nowArtist.textContent=t.artist_name||'Artista desconocido'; els.nowAlbum.textContent=t.album_name||'ẞeta Online'; els.qualityPill.textContent='ONLINE'; els.nowFavoriteBtn.disabled=true; els.nowFavoriteBtn.classList.remove('active'); els.nowFavoriteBtn.textContent='♡'; const cover=t.album_image||t.image; if(cover){els.coverArt.src=cover;els.coverArt.hidden=false;els.coverFallback.hidden=true;}else{els.coverArt.hidden=true;els.coverFallback.hidden=false;} updateOnlineBackground(t); try{if('mediaSession' in navigator)navigator.mediaSession.metadata=new MediaMetadata({title:t.name||'',artist:t.artist_name||'',album:t.album_name||'ẞeta Online',artwork:cover?[{src:cover}]:[]});}catch{} return; }
    els.nowFavoriteBtn.disabled=false; const song=songById(state.currentId);if(!song){els.nowTitle.textContent='Ninguna canción seleccionada';els.nowArtist.textContent='Añade tus archivos de audio para comenzar';els.nowAlbum.textContent='Biblioteca local';els.coverArt.hidden=true;els.coverFallback.hidden=false;els.nowFavoriteBtn.classList.remove('active');updateBackground(null);return;}els.nowTitle.textContent=song.title;els.nowArtist.textContent=song.artist;els.nowAlbum.textContent=song.album;els.qualityPill.textContent=extensionOf(song.name).toUpperCase();const cover=coverSrc(song);if(cover){els.coverArt.src=cover;els.coverArt.hidden=false;els.coverFallback.hidden=true;}else{els.coverArt.hidden=true;els.coverFallback.hidden=false;}els.nowFavoriteBtn.classList.toggle('active',Boolean(song.favorite));els.nowFavoriteBtn.textContent=song.favorite?'♥':'♡'; try{if('mediaSession' in navigator){navigator.mediaSession.metadata=new MediaMetadata({title:song.title,artist:song.artist,album:song.album});}}catch{} if(document.hidden && typeof Notification!=='undefined' && Notification.permission==='granted'){new Notification('ẞetaMusic',{body:`${song.title} — ${song.artist}`});}}

  function createSecondaryDeck(){
    if(secondaryAudio)return;
    secondaryAudio=new Audio(); secondaryAudio.preload='auto'; secondaryAudio.volume=1; secondaryAudio.style.display='none'; secondaryAudio.setAttribute('aria-hidden','true');
    document.body.appendChild(secondaryAudio);
    secondaryAudio.addEventListener('play',()=>{if(els.audio===secondaryAudio){setPlayButtonState(true);resumeAudioContextIfNeeded();}});
    secondaryAudio.addEventListener('pause',()=>{if(els.audio===secondaryAudio){setPlayButtonState(false);resumeAudioContextIfNeeded();}});
    secondaryAudio.addEventListener('error',()=>{if(els.audio===secondaryAudio)showToast('Este archivo no se puede reproducir.');});
    secondaryAudio.addEventListener('timeupdate',()=>{if(els.audio===secondaryAudio)onTimeUpdate();});
    secondaryAudio.addEventListener('loadedmetadata',()=>{if(els.audio===secondaryAudio)onMetadataLoaded();});
    secondaryAudio.addEventListener('ended',async()=>{if(els.audio===secondaryAudio&&!transitionTimer)await handleEnded();});
  }
  function activeAudio(){return els.audio;}
  function deckForAudio(el){return el===secondaryAudio?'secondary':'primary';}
  function deckGainForAudio(el){return el===secondaryAudio?secondaryDeckGain:primaryDeckGain;}
  function setDeckActive(el){els.audio=el;activeDeck=el===secondaryAudio?'secondary':'primary';}
  function clearDeckAudio(deck) {
    if (!deck) return;
    deck.pause();
    if (deck.dataset.objectUrl) { URL.revokeObjectURL(deck.dataset.objectUrl); delete deck.dataset.objectUrl; }
    delete deck.dataset.preloadId;
    deck.removeAttribute('src');
    deck.load();
  }
  function stopSecondary(){if(!secondaryAudio)return;clearDeckAudio(secondaryAudio);}
  async function setCurrentTrack(id,{autoplay=false,restoreTime=0}={}){
    const song=songById(id);if(!song)return;
    transitionToken++; if(transitionTimer){clearTimeout(transitionTimer);transitionTimer=null;}
    state.currentId=id;lastCountedPlayId=null;lastListenPosition=Number(restoreTime)||0;setPlayButtonState(false);els.seekBar.value='0';updateSeekFill(0);state.queueIndex=state.queueIds.indexOf(id);if(state.queueIndex<0){state.queueIds=state.library.map(s=>s.id);state.queueIndex=state.queueIds.indexOf(id);}
    await updateBackground(song);
    stopSecondary();
    const objectUrl=URL.createObjectURL(song.blob);
    releaseAudioUrl();
    els.audio.dataset.objectUrl=objectUrl;els.audio.src=objectUrl;els.audio.load();
    state.resumeTime=restoreTime||0;updateNowPlaying();renderQueue();renderLibrary();persistState({resumeTime:state.resumeTime});
    if(autoplay){try{await ensureAudioGraph();await resumeContext();if(state.fadeInEnabled){const g=deckGainForAudio(els.audio);if(g){g.gain.cancelScheduledValues(audioContext.currentTime);g.gain.setValueAtTime(0,audioContext.currentTime);g.gain.linearRampToValueAtTime(1,audioContext.currentTime+state.fadeInSeconds);}}await els.audio.play();}catch(e){console.debug(e);}}
  }
  function releaseAudioUrl(){if(els.audio.dataset.objectUrl){URL.revokeObjectURL(els.audio.dataset.objectUrl);delete els.audio.dataset.objectUrl;}}
  function getNextQueueId(){if(!state.queueIds.length)return null;let next=state.queueIndex+1;if(next>=state.queueIds.length){if(state.repeat==='all'||state.shuffle)next=0;else return null;}return state.queueIds[next]||null;}
  function inactiveAudioDeck(){const primary=document.getElementById('audio');return els.audio===secondaryAudio?primary:secondaryAudio;}
  function findPreloadedDeck(id){const wanted=String(id);return [document.getElementById('audio'),secondaryAudio].find(deck=>deck&&deck!==els.audio&&deck.dataset.preloadId===wanted&&deck.dataset.objectUrl)||null;}
  function preloadNextTrack(){
    if(!state.gaplessEnabled||!secondaryAudio||transitionTimer)return;
    const nextId=getNextQueueId();if(!nextId||nextId===state.currentId)return;
    const song=songById(nextId),deck=inactiveAudioDeck();if(!song||!deck||deck===els.audio)return;
    const wanted=String(nextId);
    if(deck.dataset.preloadId===wanted&&deck.dataset.objectUrl&&deck.getAttribute('src'))return;
    clearDeckAudio(deck);
    const url=URL.createObjectURL(song.blob);deck.dataset.objectUrl=url;deck.dataset.preloadId=wanted;deck.src=url;deck.load();
  }
  async function playById(id){state.onlineCurrentTrack=null;state.onlineCurrentIndex=-1;if(id===state.currentId)return togglePlay();await setCurrentTrack(id,{autoplay:true});}
  async function togglePlay(){if(state.onlineCurrentTrack){try{if(els.audio.paused)await els.audio.play();else els.audio.pause();}catch(e){console.error(e);showToast('No se pudo reproducir la pista online.');}return;}if(!state.currentId){if(state.library[0])await setCurrentTrack(state.library[0].id,{autoplay:true});else showToast('Añade una canción primero.');return;}try{await ensureAudioGraph();await resumeContext();if(els.audio.paused){if(typeof Notification!=='undefined'&&Notification.permission==='default')Notification.requestPermission().catch(()=>{});const g=deckGainForAudio(els.audio);if(g&&state.fadeInEnabled){const now=audioContext.currentTime;g.gain.cancelScheduledValues(now);g.gain.setValueAtTime(0,now);g.gain.linearRampToValueAtTime(1,now+state.fadeInSeconds);}await els.audio.play();}else if(state.fadeOutEnabled&&deckGainForAudio(els.audio)){await fadePause();}else els.audio.pause();}catch(e){console.error(e);showToast('No se pudo iniciar la reproducción.');}}
  async function fadePause(){const g=deckGainForAudio(els.audio);const d=Math.max(0,Number(state.fadeOutSeconds)||0);if(!g||!d){els.audio.pause();return;}const now=audioContext.currentTime;g.gain.cancelScheduledValues(now);g.gain.setValueAtTime(g.gain.value,now);g.gain.linearRampToValueAtTime(0,now+d);await new Promise(r=>setTimeout(r,d*1000));if(els.audio.paused)return;els.audio.pause();g.gain.setValueAtTime(1,audioContext.currentTime);}

  async function playNext(userRequested=false){
    if(state.onlineCurrentTrack){ await playNextOnline(); return; }
    if(userRequested&&transitionTimer){clearTimeout(transitionTimer);transitionTimer=null;transitionToken++;crossfadeStartedForId=null;}
    if(!state.queueIds.length)return;
    if(state.repeat==='one'&&!userRequested){els.audio.currentTime=0;await els.audio.play().catch(()=>{});return;}
    let next=state.queueIndex+1;
    if(next>=state.queueIds.length){if(state.repeat==='all'||state.shuffle)next=0;else return;}
    const nextId=state.queueIds[next];if(!nextId)return;
    if(!userRequested&&state.crossfadeEnabled&&Number(state.crossfadeSeconds)>0&&Number(els.audio.duration)>0){await crossfadeTo(nextId);return;}
    const preloadedDeck=state.gaplessEnabled?findPreloadedDeck(nextId):null;
    if(preloadedDeck){
      const oldAudio=els.audio;
      try{await ensureAudioGraph();await resumeContext();}catch{}
      preloadedDeck.pause();
      try{preloadedDeck.currentTime=0;}catch{}
      setDeckActive(preloadedDeck);
      try{await preloadedDeck.play();}
      catch(error){setDeckActive(oldAudio);console.warn('El audio precargado no pudo iniciarse; se recarga la pista.',error);await setCurrentTrack(nextId,{autoplay:true});return;}
      state.currentId=nextId;state.queueIndex=state.queueIds.indexOf(nextId);lastCountedPlayId=null;lastListenPosition=0;crossfadeStartedForId=null;state.resumeTime=0;
      const now=audioContext?.currentTime||0,oldGain=deckGainForAudio(oldAudio),newGain=deckGainForAudio(preloadedDeck);
      if(oldGain){oldGain.gain.cancelScheduledValues(now);oldGain.gain.setValueAtTime(0,now);}
      if(newGain){newGain.gain.cancelScheduledValues(now);newGain.gain.setValueAtTime(1,now);}
      clearDeckAudio(oldAudio);
      delete preloadedDeck.dataset.preloadId;
      updateNowPlaying();renderQueue();renderLibrary();persistState({resumeTime:0});preloadNextTrack();return;
    }
    await setCurrentTrack(nextId,{autoplay:true});
  }
  function playPrevious(){if(state.onlineCurrentTrack){playPreviousOnline();return;}if(!state.queueIds.length)return;if(els.audio.currentTime>3){els.audio.currentTime=0;return;}const index=state.queueIndex<=0?state.queueIds.length-1:state.queueIndex-1;if(state.repeat==='off'&&!state.shuffle&&state.queueIndex<=0)return;setCurrentTrack(state.queueIds[index],{autoplay:true});}
  async function handleEnded(){if(state.onlineCurrentTrack){await playNextOnline();return;}if(state.repeat==='one'){els.audio.currentTime=0;await els.audio.play().catch(()=>{});return;}await playNext(false);}
  async function crossfadeTo(nextId){
    const nextSong=songById(nextId);if(!nextSong){await setCurrentTrack(nextId,{autoplay:true});return;}
    await ensureAudioGraph();await resumeContext();
    const token=++transitionToken, oldAudio=els.audio, newAudio=oldAudio===secondaryAudio?document.getElementById('audio'):secondaryAudio;
    if(!newAudio){await setCurrentTrack(nextId,{autoplay:true});return;}
    const preloaded=newAudio.dataset.preloadId===String(nextId)&&Boolean(newAudio.dataset.objectUrl);
    if(!preloaded){clearDeckAudio(newAudio);const url=URL.createObjectURL(nextSong.blob);newAudio.dataset.objectUrl=url;newAudio.dataset.preloadId=String(nextId);newAudio.src=url;}
    newAudio.currentTime=0;newAudio.volume=1;if(!preloaded)newAudio.load();
    const oldGain=deckGainForAudio(oldAudio),newGain=deckGainForAudio(newAudio);if(!oldGain||!newGain){await setCurrentTrack(nextId,{autoplay:true});return;}
    const now=audioContext.currentTime,d=Math.max(0.5,Math.min(12,Number(state.crossfadeSeconds)||5));
    newGain.gain.cancelScheduledValues(now);oldGain.gain.cancelScheduledValues(now);newGain.gain.setValueAtTime(0,now);oldGain.gain.setValueAtTime(Math.max(0,oldGain.gain.value),now);
    try{await newAudio.play();}catch(e){await setCurrentTrack(nextId,{autoplay:true});return;}
    newGain.gain.linearRampToValueAtTime(1,now+d);oldGain.gain.linearRampToValueAtTime(0,now+d);
    transitionTimer=setTimeout(async()=>{
      if(token!==transitionToken)return;
      clearDeckAudio(oldAudio);
      state.currentId=nextId;state.queueIndex=state.queueIds.indexOf(nextId);lastCountedPlayId=null;lastListenPosition=0;setDeckActive(newAudio);crossfadeStartedForId=null;state.resumeTime=0;
      const activeGain=deckGainForAudio(newAudio);if(activeGain)activeGain.gain.setValueAtTime(1,audioContext.currentTime);
      transitionTimer=null;setPlayButtonState(!newAudio.paused);updateNowPlaying();renderQueue();renderLibrary();persistState({resumeTime:0});preloadNextTrack();
    },d*1000+40);
  }
  function resumeContext(){return audioContext?.state==='suspended'?audioContext.resume():Promise.resolve();}
  function toggleShuffle(){state.shuffle=!state.shuffle;const current=state.currentId;state.queueIds=state.shuffle?(current?[current,...smartShuffledIds(state.library.map(s=>s.id).filter(id=>id!==current))]:smartShuffledIds(state.library.map(s=>s.id))):state.library.map(s=>s.id);state.queueIndex=current?state.queueIds.indexOf(current):-1;renderQueue();updateControls();persistState();showToast(state.shuffle?'Aleatorio activado':'Aleatorio desactivado');}
  function cycleRepeat(){state.repeat=state.repeat==='off'?'all':state.repeat==='all'?'one':'off';updateControls();persistState();showToast(state.repeat==='off'?'Repetición desactivada':state.repeat==='all'?'Repetir lista':'Repetir canción');}
  function updateControls(){els.shuffleBtn.classList.toggle('active',state.shuffle);els.repeatBtn.classList.toggle('active',state.repeat!=='off');els.repeatBtn.textContent=state.repeat==='one'?'↻1':'↻';}
  function updatePanelVisibility(animate = true){
    const layout = document.querySelector('.content-layout');
    const stack = document.querySelector('.side-stack');
    const panel = els.playlistPanel;
    const token = ++queueAnimationToken;
    clearTimeout(queueAnimationTimer);
    if(!panel || !layout){ return; }
    if(!animate){
      panel.classList.remove('queue-closing','queue-opening');
      layout.classList.remove('queue-opening','queue-closing');
      if(state.playlistOpen){panel.style.display='';layout.classList.remove('queue-hidden');}
      else {layout.classList.add('queue-hidden');panel.style.display='none';}
    } else if(state.playlistOpen){
      panel.style.display='';
      layout.classList.remove('queue-hidden','queue-closing');
      panel.classList.remove('queue-closing');
      layout.classList.add('queue-opening');
      panel.classList.add('queue-opening');
      requestAnimationFrame(()=>{if(token!==queueAnimationToken)return;panel.classList.add('queue-reveal');});
      queueAnimationTimer=setTimeout(()=>{if(token!==queueAnimationToken)return;panel.classList.remove('queue-opening','queue-reveal');layout.classList.remove('queue-opening');},620);
    } else {
      panel.classList.remove('queue-opening','queue-reveal');
      panel.classList.add('queue-closing');
      layout.classList.add('queue-closing');
      queueAnimationTimer=setTimeout(()=>{
        if(token!==queueAnimationToken)return;
        layout.classList.add('queue-hidden');
        panel.style.display='none';
        panel.classList.remove('queue-closing');
        layout.classList.remove('queue-closing');
      },300);
    }
    if (stack) stack.setAttribute('aria-hidden', state.playlistOpen ? 'false' : 'true');
    els.togglePlaylist.title = state.playlistOpen ? 'Ocultar cola' : 'Mostrar cola';
    els.togglePlaylist.setAttribute('aria-pressed', String(state.playlistOpen));
    els.togglePlaylist.classList.toggle('active', state.playlistOpen);
  }
  function updateStats(){const favorites=state.library.filter(s=>s.favorite).length;els.libraryStatus.textContent=`${state.library.length} canción${state.library.length===1?'':'es'} local${state.library.length===1?'':'es'}`;els.statsStatus.textContent=`${favorites} favorita${favorites===1?'':'s'} · ${state.playlists.length} playlist${state.playlists.length===1?'':'s'}`;}
  function setVolume(value){state.volume=clamp(value,0,1);els.audio.volume=1;if(secondaryAudio)secondaryAudio.volume=1;if(masterGain)masterGain.gain.value=state.volume*getSafeHeadroom();els.volumeBar.value=String(state.volume);els.volumeBar.style.setProperty('--volume-progress',`${state.volume*100}%`);els.volumeLabel.textContent=`${Math.round(state.volume*100)}%`;}
  async function toggleFavorite(id){const song=songById(id);if(!song)return;song.favorite=!song.favorite;await idbRequest(tx(SONG_STORE,'readwrite').put(song));renderAll();showToast(song.favorite?'Añadida a favoritas':'Quitada de favoritas');}
  function addCurrentSongToPlaylist() {
    if (state.onlineCurrentTrack) { showToast('Las pistas online no se pueden guardar en playlists locales.'); return; }
    if (state.currentId && songById(state.currentId)) { openPlaylistPicker(state.currentId); return; }
    showToast('Selecciona una canción primero.');
  }
  function addToQueue(id) { if (!songById(id)) return; if (!state.queueIds.includes(id)) state.queueIds.push(id); renderQueue(); persistState(); showToast('Añadida a la cola.'); }
  function clearQueue() { if (!state.currentId) { state.queueIds = []; state.queueIndex = -1; } else { state.queueIds = [state.currentId]; state.queueIndex = 0; } renderQueue(); persistState(); showToast('Cola limpiada.'); }
  async function saveQueueAsPlaylist() { const ids = state.queueIds.filter(id => songById(id)); if (!ids.length) { showToast('La cola está vacía.'); return; } openPlaylistModal(null, null, ids); }
  function openPlaylistModal(playlistId = null, songId = null, initialIds = null) {
    state.editingPlaylistId = playlistId; state.pickerSongId = songId;
    els.playlistModal.classList.add('open'); els.playlistModal.setAttribute('aria-hidden', 'false');
    els.playlistNameInput.value = playlistId ? (state.playlists.find(item => item.id === playlistId)?.name || '') : (initialIds ? 'Mi cola' : '');
    els.confirmPlaylistBtn.textContent = playlistId ? 'Guardar' : 'Crear playlist';
    els.playlistModal.dataset.initialIds = initialIds ? JSON.stringify(initialIds) : '';
    setTimeout(() => els.playlistNameInput.focus(), 50);
  }
  function closePlaylistModal() { els.playlistModal.classList.remove('open'); els.playlistModal.setAttribute('aria-hidden', 'true'); }
  async function confirmPlaylist() {
    const name = els.playlistNameInput.value.trim();
    if (!name) { showToast('Escribe un nombre.'); return; }
    try {
      const existing = state.editingPlaylistId ? state.playlists.find(item => item.id === state.editingPlaylistId) : null;
      if (existing) {
        existing.name = name; existing.updatedAt = Date.now();
        await savePlaylistRecords([existing]); showToast('Playlist actualizada.');
      } else {
        let ids = [];
        try { ids = JSON.parse(els.playlistModal.dataset.initialIds || '[]'); } catch {}
        const pickedSongId = state.pickerSongId;
        if (pickedSongId && songById(pickedSongId) && !ids.includes(pickedSongId)) ids.push(pickedSongId);
        const playlist = { id: crypto.randomUUID(), name, songIds: [...new Set(ids.filter(id => songById(id)))], createdAt: Date.now(), updatedAt: Date.now() };
        await savePlaylistRecords([playlist]);
        state.playlists = [...state.playlists.filter(item => item.id !== playlist.id), playlist].sort((a, b) => a.createdAt - b.createdAt);
        showToast('Playlist creada.');
      }
      state.editingPlaylistId = null; state.pickerSongId = null; state.playlistDetailId = null; state.albumDetail = null;
      state.view = 'playlists'; state.query = ''; els.librarySearch.value = '';
      syncViewTabs(); closePlaylistModal(); renderAll(); persistState();
    } catch (error) { console.error(error); showToast('No se pudo guardar la playlist. Comprueba el almacenamiento.'); }
  }
  function openPlaylistPicker(songId) {
    state.pickerSongId = songId;
    const playlists = [...state.playlists].sort((a, b) => a.name.localeCompare(b.name));
    els.playlistPickerList.innerHTML = playlists.length ? playlists.map(playlist => `<button class="picker-item" data-picker="${escapeAttr(playlist.id)}" type="button"><span>${escapeHTML(playlist.name)}</span><small>${(playlist.songIds || []).length} canciones</small></button>`).join('') : '<div class="empty-state" style="min-height:100px"><p>No hay playlists todavía. Puedes crear una nueva.</p></div>';
    els.playlistPickerList.querySelectorAll('[data-picker]').forEach(button => button.addEventListener('click', () => addSongToPlaylist(button.dataset.picker, songId)));
    els.playlistPickerModal.classList.add('open'); els.playlistPickerModal.setAttribute('aria-hidden', 'false');
  }
  function closePlaylistPicker() { els.playlistPickerModal.classList.remove('open'); els.playlistPickerModal.setAttribute('aria-hidden', 'true'); }
  async function addSongToPlaylist(playlistId, songId) {
    const playlist = state.playlists.find(item => item.id === playlistId); if (!playlist) return;
    playlist.songIds = Array.isArray(playlist.songIds) ? playlist.songIds : [];
    if (!playlist.songIds.includes(songId)) playlist.songIds.push(songId);
    playlist.updatedAt = Date.now();
    try {
      await savePlaylistRecords([playlist]); closePlaylistPicker();
      if (state.view === 'playlists' && state.playlistDetailId === playlist.id) renderLibrary();
      renderAll(); showToast(`Añadida a ${playlist.name}.`);
    } catch (error) { console.error(error); showToast('No se pudo actualizar la playlist.'); }
  }
  async function deletePlaylist(id) {
    const playlist = state.playlists.find(item => item.id === id);
    if (!playlist || !confirm(`¿Eliminar la playlist “${playlist.name}”?`)) return;
    try {
      const transaction = db.transaction(PLAYLIST_STORE, 'readwrite'); transaction.objectStore(PLAYLIST_STORE).delete(id); await transactionDone(transaction);
      state.playlists = state.playlists.filter(item => item.id !== id); if (state.playlistDetailId === id) state.playlistDetailId = null;
      renderAll(); showToast('Playlist eliminada.');
    } catch (error) { console.error(error); showToast('No se pudo eliminar la playlist.'); }
  }
  async function playPlaylistTrack(playlistId, songId) {
    const playlist = state.playlists.find(item => item.id === playlistId); if (!playlist) return;
    const ids = (playlist.songIds || []).filter(id => songById(id)); if (!ids.includes(songId)) return;
    state.queueIds = [...ids]; state.queueIndex = state.queueIds.indexOf(songId);
    await setCurrentTrack(songId, { autoplay: true }); persistState(); renderQueue();
  }
  async function playPlaylist(id){const p=state.playlists.find(x=>x.id===id);if(!p)return;const ids=p.songIds.filter(x=>songById(x));if(!ids.length){showToast('La playlist está vacía.');return;}state.queueIds=[...ids];state.queueIndex=0;await setCurrentTrack(ids[0],{autoplay:true});persistState();renderQueue();}

  function recordPlay(id){const song=songById(id);if(!song)return;song.playCount=(song.playCount||0)+1;song.lastPlayed=Date.now();song.listenSeconds=Math.max(0,Number(song.listenSeconds)||0);idbRequest(tx(SONG_STORE,'readwrite').put(song)).catch(console.error);const entry={songId:id,playedAt:Date.now()};state.history.unshift(entry);state.history=state.history.slice(0,500);idbRequest(tx(HISTORY_STORE,'readwrite').add(entry)).catch(console.error);updateStats();if(state.view==='recommendations')renderRecommendations();}
  function trackListeningTime() {
    const song = !state.onlineCurrentTrack && songById(state.currentId);
    const position = Number(els.audio.currentTime) || 0;
    if (!song || els.audio.paused || els.audio.seeking) { lastListenPosition = position; return; }
    if (lastListenPosition !== null) {
      const delta = position - lastListenPosition;
      if (delta > 0 && delta <= 2.5) song.listenSeconds = Math.max(0, Number(song.listenSeconds)||0) + delta;
    }
    lastListenPosition = position;
    const now = Date.now();
    if (now - lastListenWriteAt >= 15000) {
      lastListenWriteAt = now;
      idbRequest(tx(SONG_STORE,'readwrite').put(song)).catch(console.error);
      if (state.view==='recommendations') renderRecommendations();
    }
  }
  function onMetadataLoaded(){const seconds=Number(els.audio.duration);els.duration.textContent=formatTime(seconds);els.seekBar.value='0';updateSeekFill(0);if(state.resumeTime>0&&state.resumeTime<seconds-1)els.audio.currentTime=state.resumeTime;const song=songById(state.currentId);if(song&&(!song.duration||Math.abs(song.duration-seconds)>1)&&Number.isFinite(seconds)){song.duration=seconds;idbRequest(tx(SONG_STORE,'readwrite').put(song)).catch(console.error);}state.resumeTime=0;lastListenPosition=Number(els.audio.currentTime)||0;applyReplayGain();preloadNextTrack();}
  function onTimeUpdate(){trackListeningTime();updateLyricsHighlight();const duration=Number(els.audio.duration),current=Number(els.audio.currentTime);els.currentTime.textContent=formatTime(current);if(duration>0){const progress=current/duration*100;els.seekBar.value=String(progress);updateSeekFill(progress);}else updateSeekFill(0);if(state.currentId&&Math.floor(current)%5===0)persistState({resumeTime:current});if(state.crossfadeEnabled&&state.crossfadeSeconds>0&&duration>0&&!transitionTimer&&crossfadeStartedForId!==state.currentId){const remaining=duration-current;if(remaining<=Math.min(Number(state.crossfadeSeconds),duration-0.2)&&remaining>0.15&&!els.audio.paused){crossfadeStartedForId=state.currentId;playNext(false).catch(()=>{});}}}
  async function ensureAudioGraph(){if(audioGraphReady)return;const C=window.AudioContext||window.webkitAudioContext;if(!C)return;
    createSecondaryDeck();audioContext=new C();
    sourceNode=audioContext.createMediaElementSource(document.getElementById('audio'));secondarySource=audioContext.createMediaElementSource(secondaryAudio);
    primaryDeckGain=audioContext.createGain();secondaryDeckGain=audioContext.createGain();primaryDeckGain.gain.value=1;secondaryDeckGain.gain.value=0;
    const freqs=[31,62,125,250,500,1000,2000,4000,8000,16000],qValues=[0.72,0.72,0.78,0.82,0.86,0.9,0.95,1,1,0.95];
    eqFilters=freqs.map((f,i)=>{const filter=audioContext.createBiquadFilter();filter.type='peaking';filter.frequency.value=f;filter.Q.value=qValues[i];filter.gain.value=Number(state.eqBands?.[i]||0);return filter;});
    bassFilter=audioContext.createBiquadFilter();bassFilter.type='lowshelf';bassFilter.frequency.value=82;bassFilter.gain.value=Number(state.bassBoost||0);
    balanceNode=audioContext.createStereoPanner();balanceNode.pan.value=Number(state.balance||0);
    masterGain=audioContext.createGain();masterGain.gain.value=state.volume*getSafeHeadroom();
    limiterNode=audioContext.createDynamicsCompressor();limiterNode.threshold.value=-8;limiterNode.knee.value=18;limiterNode.ratio.value=state.finalLimiterEnabled?10:1;limiterNode.attack.value=.002;limiterNode.release.value=.12;
    sourceNode.connect(primaryDeckGain);secondarySource.connect(secondaryDeckGain);primaryDeckGain.connect(eqFilters[0]);secondaryDeckGain.connect(eqFilters[0]);
    let node=eqFilters[0];for(let i=1;i<eqFilters.length;i++){node.connect(eqFilters[i]);node=eqFilters[i];}node.connect(bassFilter);bassFilter.connect(balanceNode);balanceNode.connect(masterGain);masterGain.connect(limiterNode);limiterNode.connect(audioContext.destination);
    audioGraphReady=true;resumeAudioContextIfNeeded();
  }
  function applyAudioSettings(){if(!audioGraphReady)return;eqFilters.forEach((f,i)=>f.gain.value=clamp(Number(state.eqBands?.[i]||0),-15,15));if(bassFilter)bassFilter.gain.value=clamp(Number(state.bassBoost||0),0,8);if(balanceNode)balanceNode.pan.value=clamp(Number(state.balance||0),-1,1);if(masterGain)masterGain.gain.value=state.volume*getSafeHeadroom();if(limiterNode)limiterNode.ratio.value=state.finalLimiterEnabled?10:1;}
  function getSafeHeadroom(){const gains=(state.eqBands||[]).map(Number);const maxBoost=Math.max(0,...gains,Number(state.bassBoost||0));return Math.pow(10,-Math.max(0,maxBoost-1.5)/20);}
  function resumeAudioContextIfNeeded(){if(!els.audio.paused&&audioGraphReady&&audioContext?.state==='suspended')audioContext.resume().catch(()=>{});}
  async function updateBackground(song) {
    const root = document.documentElement;
    if (state.dynamicBackgroundEnabled && song?.coverBlob) {
      const url = coverSrc(song).replace(/"/g, '%22');
      root.style.setProperty('--bg-image', `url("${url}")`);
    } else {
      root.style.removeProperty('--bg-image');
    }
    if (!song?.coverBlob) {
      root.style.removeProperty('--accent'); root.style.removeProperty('--accent-2'); return;
    }
    const palette = await extractPalette(song.coverBlob);
    if (palette.length >= 2 && song.id === state.currentId) {
      root.style.setProperty('--accent', palette[0]); root.style.setProperty('--accent-2', palette[1]);
    }
  }
  async function updateOnlineBackground(track) {
    const root = document.documentElement;
    const cover = track?.album_image || track?.image;
    if (state.dynamicBackgroundEnabled && cover) {
      try { const parsed = new URL(cover); if (['https:', 'http:'].includes(parsed.protocol)) root.style.setProperty('--bg-image', `url("${parsed.href.replace(/"/g, '%22')}")`); else root.style.removeProperty('--bg-image'); }
      catch { root.style.removeProperty('--bg-image'); }
    } else root.style.removeProperty('--bg-image');
    if (!cover) { root.style.removeProperty('--accent'); root.style.removeProperty('--accent-2'); return; }
    try {
      const parsed = new URL(cover); if (!['https:', 'http:'].includes(parsed.protocol)) return;
      const img = new Image(); img.crossOrigin = 'anonymous';
      img.onload = () => {
        try {
          const canvas = document.createElement('canvas'); canvas.width = canvas.height = 40;
          const ctx = canvas.getContext('2d', { willReadFrequently: true }); ctx.drawImage(img, 0, 0, 40, 40);
          const pixels = ctx.getImageData(0, 0, 40, 40).data, colors = new Map();
          for (let i = 0; i < pixels.length; i += 16) { const r = pixels[i], g = pixels[i + 1], b = pixels[i + 2], l = (r + g + b) / 3; if (l < 24 || l > 242) continue; const key = `${Math.round(r / 24) * 24},${Math.round(g / 24) * 24},${Math.round(b / 24) * 24}`; colors.set(key, (colors.get(key) || 0) + 1); }
          const palette = [...colors.entries()].sort((a, b) => b[1] - a[1]).slice(0, 2).map(([rgb]) => `rgb(${rgb})`);
          if (palette.length >= 2 && state.onlineCurrentTrack === track) { root.style.setProperty('--accent', palette[0]); root.style.setProperty('--accent-2', palette[1]); }
        } catch {}
      };
      img.src = parsed.href;
    } catch {}
  }
  function extractPalette(blob){return new Promise(resolve=>{const url=URL.createObjectURL(blob),img=new Image();img.onload=()=>{try{const c=document.createElement('canvas');c.width=c.height=40;const ctx=c.getContext('2d',{willReadFrequently:true});ctx.drawImage(img,0,0,40,40);const p=ctx.getImageData(0,0,40,40).data,b=new Map();for(let i=0;i<p.length;i+=16){const r=p[i],g=p[i+1],bl=p[i+2],br=(r+g+bl)/3;if(br<25||br>240)continue;const k=`${Math.round(r/24)*24},${Math.round(g/24)*24},${Math.round(bl/24)*24}`;b.set(k,(b.get(k)||0)+1);}resolve([...b.entries()].sort((a,b)=>b[1]-a[1]).slice(0,8).map(([rgb])=>`rgb(${rgb})`));}catch{resolve(['#8c72ff','#4ab7ff']);}finally{URL.revokeObjectURL(url);}};img.onerror=()=>{URL.revokeObjectURL(url);resolve(['#8c72ff','#4ab7ff']);};img.src=url;});}
  function coverSrc(song){if(!song?.coverBlob)return '';if(!coverCache.has(song.id))coverCache.set(song.id,URL.createObjectURL(song.coverBlob));return coverCache.get(song.id);}

  function showSongActions(id){
    const song=songById(id);if(!song)return;
    let m=document.getElementById('songActionsModal');
    if(!m){m=document.createElement('div');m.id='songActionsModal';m.className='settings-overlay';m.setAttribute('aria-hidden','true');document.body.appendChild(m);}
    m.innerHTML=`<section class="settings-modal glass small-modal song-actions-modal"><div class="settings-header"><div><span class="settings-eyebrow">ACCIONES DE LA CANCIÓN</span><h2>${escapeHTML(song.title)}</h2><p class="modal-subtitle">Editar, personalizar y organizar esta pista.</p></div><button class="settings-close" data-close-actions>×</button></div><div class="song-action-grid"><button data-song-action="album"><span>▣</span><strong>Ir al álbum</strong><small>Ver el álbum y todas sus canciones</small></button><button data-song-action="artist"><span>♫</span><strong>Ir al artista</strong><small>Ver las canciones de este artista</small></button><button data-song-action="metadata"><span>✎</span><strong>Editar metadatos</strong><small>Título, artista, álbum y género</small></button><button data-song-action="cover"><span>▧</span><strong>Cambiar portada</strong><small>Seleccionar una imagen para esta canción</small></button><button data-song-action="rating"><span>★</span><strong>Puntuar canción</strong><small>Valor actual: ${song.rating||0}/5</small></button><button data-song-action="playlist"><span>＋</span><strong>Añadir a playlist</strong><small>Guardar esta canción en una lista</small></button><button class="danger-action" data-song-action="delete"><span>⌫</span><strong>Eliminar de biblioteca</strong><small>Quita la canción de ẞetaMusic</small></button></div></section>`;
    m.classList.add('open');m.setAttribute('aria-hidden','false');
    const close=()=>closeModalById('songActionsModal');m.querySelector('[data-close-actions]').onclick=close;
    m.onclick=e=>{if(e.target===m)close();const b=e.target.closest('[data-song-action]');if(!b)return;const action=b.dataset.songAction;close();if(action==='album')openAlbumDetail(songById(id));else if(action==='artist'){const current=songById(id);if(current)openArtistDetail(current.artist);}else if(action==='metadata')editMetadata(id);else if(action==='cover')chooseCover(id);else if(action==='rating')rateSong(id);else if(action==='playlist')openPlaylistPicker(id);else if(action==='delete')removeSong(id);};
  }
  function editMetadata(id){
    const song = songById(id);
    if (!song) return;
    document.getElementById('metadataEditorModal')?.remove();
    const modal = document.createElement('div');
    modal.id = 'metadataEditorModal';
    modal.className = 'settings-overlay';
    modal.setAttribute('aria-hidden', 'false');
    modal.innerHTML = `<section class="settings-modal glass small-modal metadata-editor-modal" role="dialog" aria-modal="true" aria-labelledby="metadataEditorTitle">
      <div class="settings-header"><div><span class="settings-eyebrow">BIBLIOTECA</span><h2 id="metadataEditorTitle">Editar metadatos</h2><p class="modal-subtitle">Los cambios se guardan en la biblioteca de ẞetaMusic.</p></div><button class="settings-close" data-editor-close type="button" aria-label="Cerrar">×</button></div>
      <form class="metadata-form"><label>Título<input id="metadataTitle" class="modal-input" maxlength="240" value="${escapeAttr(song.title)}" required></label><label>Artista<input id="metadataArtist" class="modal-input" maxlength="240" value="${escapeAttr(song.artist)}"></label><label>Álbum<input id="metadataAlbum" class="modal-input" maxlength="240" value="${escapeAttr(song.album)}"></label><label>Género<input id="metadataGenre" class="modal-input" maxlength="120" value="${escapeAttr(song.genre || '')}"></label><div class="modal-actions"><button data-editor-cancel class="secondary-btn" type="button">Cancelar</button><button class="primary-btn" type="submit">Guardar cambios</button></div></form>
    </section>`;
    document.body.appendChild(modal);
    requestAnimationFrame(() => modal.classList.add('open'));
    const close = () => { modal.classList.remove('open'); modal.setAttribute('aria-hidden','true'); setTimeout(() => modal.remove(), 220); };
    modal.querySelector('[data-editor-close]').addEventListener('click', close);
    modal.querySelector('[data-editor-cancel]').addEventListener('click', close);
    modal.addEventListener('click', event => { if (event.target === modal) close(); });
    modal.querySelector('form').addEventListener('submit', async event => {
      event.preventDefault();
      const current = songById(id);
      if (!current) { close(); return; }
      const title = modal.querySelector('#metadataTitle').value.trim();
      if (!title) { modal.querySelector('#metadataTitle').focus(); showToast('El título no puede estar vacío.'); return; }
      current.title = title;
      current.artist = modal.querySelector('#metadataArtist').value.trim() || 'Artista desconocido';
      current.album = modal.querySelector('#metadataAlbum').value.trim() || 'Álbum desconocido';
      current.genre = modal.querySelector('#metadataGenre').value.trim() || 'Sin género';
      current.searchText = normalizeText(`${current.title} ${current.artist} ${current.album} ${current.genre} ${current.name}`);
      try {
        await idbRequest(tx(SONG_STORE, 'readwrite').put(current));
        close(); renderAll();
        if (current.id === state.currentId) updateNowPlaying();
        showToast('Metadatos actualizados.');
      } catch (error) { console.error(error); showToast('No se pudieron guardar los metadatos.'); }
    });
    setTimeout(() => modal.querySelector('#metadataTitle')?.focus(), 40);
  }
  function chooseCover(id){
    const input=document.createElement('input');input.type='file';input.accept='image/*';input.onchange=async()=>{const f=input.files?.[0];if(!f)return;const s=songById(id);if(!s)return;s.coverBlob=f;coverCache.delete(id);await idbRequest(tx(SONG_STORE,'readwrite').put(s));renderAll();await updateBackground(s);showToast('Portada actualizada.');};input.click();
  }
  function rateSong(id){
    const song = songById(id);
    if (!song) return;
    document.getElementById('ratingEditorModal')?.remove();
    let selectedRating = Number(song.rating || 0);
    const modal = document.createElement('div');
    modal.id = 'ratingEditorModal';
    modal.className = 'settings-overlay';
    modal.setAttribute('aria-hidden', 'false');
    modal.innerHTML = `<section class="settings-modal glass small-modal rating-editor-modal" role="dialog" aria-modal="true" aria-labelledby="ratingEditorTitle">
      <div class="settings-header"><div><span class="settings-eyebrow">BIBLIOTECA</span><h2 id="ratingEditorTitle">Puntuar canción</h2><p class="modal-subtitle">Guarda tu valoración personal de esta pista.</p></div><button class="settings-close" data-rating-close type="button" aria-label="Cerrar">×</button></div>
      <div class="rating-song-name">${escapeHTML(song.title)}<span>${escapeHTML(song.artist)}</span></div>
      <div class="rating-stars" role="group" aria-label="Puntuación de cero a cinco">${[1,2,3,4,5].map(n=>`<button type="button" data-rating-value="${n}" aria-label="${n} de 5 estrellas" aria-pressed="${n<=selectedRating}">${n<=selectedRating?'★':'☆'}</button>`).join('')}</div>
      <div class="rating-value" data-rating-label>${selectedRating ? `${selectedRating} / 5` : 'Sin puntuar'}</div>
      <div class="modal-actions rating-modal-actions"><button class="text-button" data-rating-clear type="button">Quitar puntuación</button><button class="secondary-btn" data-rating-cancel type="button">Cancelar</button><button class="primary-btn" data-rating-save type="button">Guardar</button></div>
    </section>`;
    document.body.appendChild(modal);
    requestAnimationFrame(() => modal.classList.add('open'));
    const updateRating = () => {
      modal.querySelectorAll('[data-rating-value]').forEach(button => {
        const value = Number(button.dataset.ratingValue);
        button.textContent = value <= selectedRating ? '★' : '☆';
        button.setAttribute('aria-pressed', String(value <= selectedRating));
        button.classList.toggle('selected', value <= selectedRating);
      });
      modal.querySelector('[data-rating-label]').textContent = selectedRating ? `${selectedRating} / 5` : 'Sin puntuar';
    };
    const close = () => { modal.classList.remove('open'); modal.setAttribute('aria-hidden','true'); setTimeout(() => modal.remove(), 220); };
    modal.addEventListener('click', async event => {
      if (event.target === modal || event.target.closest('[data-rating-close]') || event.target.closest('[data-rating-cancel]')) { close(); return; }
      const star = event.target.closest('[data-rating-value]');
      if (star) { selectedRating = Number(star.dataset.ratingValue); updateRating(); return; }
      if (event.target.closest('[data-rating-clear]')) { selectedRating = 0; updateRating(); return; }
      if (event.target.closest('[data-rating-save]')) {
        const current = songById(id);
        if (!current) { close(); return; }
        current.rating = selectedRating;
        try {
          await idbRequest(tx(SONG_STORE, 'readwrite').put(current));
          close(); renderAll(); showToast(selectedRating ? `Puntuación guardada: ${selectedRating}/5` : 'Puntuación eliminada.');
        } catch (error) { console.error(error); showToast('No se pudo guardar la puntuación.'); }
      }
    });
    updateRating();
  }
  function openEqualizer(){
    let modal=document.getElementById('equalizerModal');if(!modal){modal=createEqualizerModal();document.body.appendChild(modal);}
    syncEqualizerUI();modal.classList.add('open');modal.setAttribute('aria-hidden','false');
  }
  function closeModalById(id){const m=document.getElementById(id);if(m){m.classList.remove('open');m.setAttribute('aria-hidden','true');}}
  function createEqualizerModal(){
    const m=document.createElement('div');m.id='equalizerModal';m.className='settings-overlay';m.setAttribute('aria-hidden','true');
    const bands=['31','62','125','250','500','1K','2K','4K','8K','16K'];
    m.innerHTML=`<section class="settings-modal glass audio-eq-modal">
      <div class="settings-header"><div><span class="settings-eyebrow">ẞETA AUDIO ENGINE</span><h2>Ecualizador</h2><p class="modal-subtitle">10 bandas · respuesta tipo AIMP · protección contra clipping</p></div><button class="settings-close" data-close-eq>×</button></div>
      <div class="eq-topbar"><div class="eq-preset-wrap"><span>PRESET</span><select id="eqPreset"><option value="flat">Plano</option><option value="bass">Bass</option><option value="rock">Rock</option><option value="pop">Pop</option><option value="vocal">Vocal</option><option value="electronic">Electronic</option><option value="acoustic">Acoustic</option><option value="custom">Personalizado</option></select></div><button class="secondary-btn" data-reset-eq>Restablecer</button><div class="eq-protect"><span class="protect-dot"></span> Headroom automático</div></div>
      <div class="eq-preamp"><div><strong>Ganancia previa</strong><small>Se ajusta automáticamente al aumentar bandas</small></div><output id="headroomValue">Protección activa</output></div>
      <div class="eq-slider-grid aimp-eq">${bands.map((x,i)=>`<label class="eq-band"><output id="eqVal${i}">0 dB</output><input aria-label="${x} Hz" type="range" min="-15" max="15" step="0.5" value="0" data-eq="${i}"><span>${x}<small>${x.includes('K')?'kHz':'Hz'}</small></span></label>`).join('')}</div>
      <div class="eq-bottom-grid"><div class="eq-control"><div><strong>Bass Boost</strong><output id="bassVal">0 dB</output></div><input id="bassSlider" type="range" min="0" max="8" step="0.5" value="0"><small>Refuerzo controlado de subgraves y graves</small></div><div class="eq-control"><div><strong>Balance</strong><output id="balanceVal">Centro</output></div><input id="balanceSlider" type="range" min="-1" max="1" step="0.01" value="0"><small>Izquierda ← · → Derecha</small></div></div>
      <div class="modal-actions"><button class="secondary-btn" data-close-eq>Cerrar</button></div>
    </section>`;
    m.addEventListener('click',e=>{if(e.target===m||e.target.closest('[data-close-eq]'))closeModalById('equalizerModal');});
    m.querySelectorAll('[data-eq]').forEach(x=>x.addEventListener('input',()=>{state.eqBands[Number(x.dataset.eq)]=Number(x.value);applyAudioSettings();syncEqualizerUI();persistState();}));
    m.querySelector('#bassSlider').addEventListener('input',e=>{state.bassBoost=Number(e.target.value);applyAudioSettings();syncEqualizerUI();persistState();});
    m.querySelector('#balanceSlider').addEventListener('input',e=>{state.balance=Number(e.target.value);applyAudioSettings();syncEqualizerUI();persistState();});
    m.querySelector('#eqPreset').addEventListener('change',e=>applyPreset(e.target.value));m.querySelector('[data-reset-eq]').addEventListener('click',()=>applyPreset('flat'));
    return m;
  }
  function syncEqualizerUI(){const m=document.getElementById('equalizerModal');if(!m)return;m.querySelectorAll('[data-eq]').forEach(x=>{const i=Number(x.dataset.eq);const v=Number(state.eqBands?.[i]||0);x.value=String(v);m.querySelector('#eqVal'+i).textContent=`${v>0?'+':''}${v} dB`;});const b=Number(state.bassBoost||0);m.querySelector('#bassSlider').value=String(b);m.querySelector('#bassVal').textContent=`+${b} dB`;m.querySelector('#balanceSlider').value=String(state.balance||0);m.querySelector('#balanceVal').textContent=state.balance<-.01?'Izquierda':state.balance>.01?'Derecha':'Centro';m.querySelector('#eqPreset').value='custom';m.querySelector('#headroomValue').textContent=`−${Math.round((1-getSafeHeadroom())*100)}% de ganancia para evitar clipping`; }
  function applyPreset(name){const presets={flat:Array(10).fill(0),bass:[3,4,3,2,1,0,0,0,0,0],rock:[4,3,2,0,-1,-1,2,3,4,3],pop:[-1,1,3,4,2,0,-1,-1,1,2],vocal:[-3,-2,0,2,4,4,2,0,-1,-2],electronic:[3,2,1,0,-1,1,3,4,3,2],acoustic:[2,1,0,1,2,2,1,2,3,2]};state.eqBands=[...(presets[name]||presets.flat)];if(name==='bass')state.bassBoost=2;else if(name!=='flat')state.bassBoost=0;applyAudioSettings();syncEqualizerUI();persistState();}
  function toggleMiniPlayer(force){state.miniPlayer=typeof force==='boolean'?force:!state.miniPlayer;document.body.classList.toggle('mini-player-mode',state.miniPlayer);persistState();showToast(state.miniPlayer?'Mini reproductor activado':'Mini reproductor desactivado');}
  function openStatsModal(){let m=document.getElementById('statsModal');if(!m){m=document.createElement('div');m.id='statsModal';m.className='settings-overlay';m.setAttribute('aria-hidden','true');document.body.appendChild(m);}const total=state.library.length,plays=state.library.reduce((n,s)=>n+(s.playCount||0),0),fav=state.library.filter(s=>s.favorite).length,rated=state.library.filter(s=>s.rating),avg=rated.length?(rated.reduce((n,s)=>n+s.rating,0)/rated.length).toFixed(1):'0.0',size=state.library.reduce((n,s)=>n+(s.size||0),0),duration=state.library.reduce((n,s)=>n+(s.duration||0),0);m.innerHTML=`<section class="settings-modal glass stats-modal"><div class="settings-header"><div><span class="settings-eyebrow">BIBLIOTECA</span><h2>Estadísticas</h2><p class="modal-subtitle">Resumen de tu colección y reproducción.</p></div><button class="settings-close" data-close-stats>×</button></div><div class="stats-grid"><div><strong>${total}</strong><span>Canciones</span></div><div><strong>${plays}</strong><span>Reproducciones</span></div><div><strong>${fav}</strong><span>Favoritas</span></div><div><strong>${avg}</strong><span>Valoración media</span></div><div><strong>${formatBytes(size)}</strong><span>Biblioteca</span></div><div><strong>${formatTime(duration)}</strong><span>Duración total</span></div></div><div class="stats-footer">${state.playlists.length} playlists · ${state.history.length} registros de historial</div></section>`;m.addEventListener('click',e=>{if(e.target===m||e.target.closest('[data-close-stats]'))closeModalById('statsModal');},{once:true});m.classList.add('open');m.setAttribute('aria-hidden','false');}
  function applyTheme(theme){state.theme=theme;document.documentElement.dataset.theme=theme;persistState();}
  function showDetailedStats(){openStatsModal();}
  function handleEnhancedAction(e){if(e.target.closest('#emptyAddBtn')){els.filePicker.click();return;}}
  function setupMediaSession(){if(!('mediaSession' in navigator))return;const bind=(name,fn)=>{try{navigator.mediaSession.setActionHandler(name,fn);}catch{}};bind('play',()=>els.audio.play());bind('pause',()=>els.audio.pause());bind('nexttrack',()=>playNext(true));bind('previoustrack',playPrevious);}
  async function removeSong(id){const song=songById(id);if(!song)return;if(!confirm(`¿Eliminar “${song.title}” de la biblioteca?`))return;try{await idbRequest(tx(SONG_STORE,'readwrite').delete(id));state.library=state.library.filter(s=>s.id!==id);state.queueIds=state.queueIds.filter(x=>x!==id);state.playlists.forEach(p=>p.songIds=p.songIds.filter(x=>x!==id));for(const p of state.playlists)await idbRequest(tx(PLAYLIST_STORE,'readwrite').put(p));if(id===state.currentId){state.currentId=state.queueIds[0]||null;if(state.currentId)await setCurrentTrack(state.currentId);else{els.audio.pause();releaseAudioUrl();els.audio.removeAttribute('src');els.audio.load();}}renderAll();}catch(e){console.error(e);showToast('No se pudo eliminar.');}}
  function emptyStateHTML(title,message){return `<div class="empty-state"><div><div class="empty-icon">♫</div><h3>${escapeHTML(title)}</h3><p>${escapeHTML(message)}</p>${!state.library.length?'<button class="primary-btn" id="emptyAddBtn">Añadir música</button>':''}</div></div>`;}
  function openSettings(){els.settingsOverlay.classList.add('open');els.settingsOverlay.setAttribute('aria-hidden','false');syncPlaybackSettingsUI();} function closeSettings(){els.settingsOverlay.classList.remove('open');els.settingsOverlay.setAttribute('aria-hidden','true');}
  function bindPlaybackSettings(){
    const bind=(el,fn)=>{if(!el)return;el.addEventListener('change',fn);};
    bind(els.performanceModeToggle, () => {
      const enable = els.performanceModeToggle.checked;
      if (enable && !state.performanceMode) state.performanceRestore = { glassEnabled: state.glassEnabled, transparencyEnabled: state.transparencyEnabled, animationsEnabled: state.animationsEnabled };
      state.performanceMode = enable;
      state.performanceProfile = 'custom';
      if (!enable && state.performanceRestore) {
        state.glassEnabled = state.performanceRestore.glassEnabled !== false;
        state.transparencyEnabled = state.performanceRestore.transparencyEnabled !== false;
        state.animationsEnabled = state.performanceRestore.animationsEnabled !== false;
        state.performanceRestore = null;
      }
      applyPerformanceMode(); syncPlaybackSettingsUI(); persistState();
    });
    bind(els.glassEffectToggle,()=>{state.glassEnabled=els.glassEffectToggle.checked;state.performanceProfile='custom';applyUiEffects();persistState();});
    bind(els.transparencyToggle,()=>{state.transparencyEnabled=els.transparencyToggle.checked;state.performanceProfile='custom';applyUiEffects();persistState();});
    bind(els.animationsToggle,()=>{state.animationsEnabled=els.animationsToggle.checked;state.performanceProfile='custom';applyUiEffects();persistState();});
    bind(els.dynamicBackgroundToggle,()=>{state.dynamicBackgroundEnabled=els.dynamicBackgroundToggle.checked;state.performanceProfile='custom';applyUiEffects();persistState();});
    bind(els.startupAnimationToggle,()=>{state.performanceProfile='custom';state.startupAnimationEnabled=els.startupAnimationToggle.checked;document.documentElement.classList.toggle('startup-animation-off',!state.startupAnimationEnabled);try{localStorage.setItem('auro-startup-animation-enabled',String(state.startupAnimationEnabled));}catch{}if(!state.startupAnimationEnabled&&els.startupIntro?.isConnected)els.startupIntro.remove();persistState();});
    bind(els.crossfadeToggle,()=>{state.crossfadeEnabled=els.crossfadeToggle.checked;persistState();});bind(els.crossfadeSeconds,()=>{state.crossfadeSeconds=clamp(Number(els.crossfadeSeconds.value),1,12);syncPlaybackSettingsUI();persistState();});
    bind(els.gaplessToggle,()=>{state.gaplessEnabled=els.gaplessToggle.checked;persistState();});bind(els.replayGainToggle,()=>{state.replayGainEnabled=els.replayGainToggle.checked;applyReplayGain();persistState();});bind(els.limiterToggle,()=>{state.finalLimiterEnabled=els.limiterToggle.checked;persistState();});
    bind(els.fadeInToggle,()=>{state.fadeInEnabled=els.fadeInToggle.checked;persistState();});bind(els.fadeInSeconds,()=>{state.fadeInSeconds=clamp(Number(els.fadeInSeconds.value),0,5);syncPlaybackSettingsUI();persistState();});bind(els.fadeOutToggle,()=>{state.fadeOutEnabled=els.fadeOutToggle.checked;persistState();});bind(els.fadeOutSeconds,()=>{state.fadeOutSeconds=clamp(Number(els.fadeOutSeconds.value),0,5);syncPlaybackSettingsUI();persistState();});
  }
  function syncPlaybackSettingsUI() {
    if (!els.performanceModeToggle) return;
    els.performanceModeToggle.checked = Boolean(state.performanceMode);
    if (els.glassEffectToggle) { els.glassEffectToggle.checked = Boolean(state.glassEnabled); els.glassEffectToggle.disabled = Boolean(state.performanceMode); }
    if (els.transparencyToggle) { els.transparencyToggle.checked = Boolean(state.transparencyEnabled); els.transparencyToggle.disabled = Boolean(state.performanceMode); }
    if (els.animationsToggle) { els.animationsToggle.checked = Boolean(state.animationsEnabled); els.animationsToggle.disabled = Boolean(state.performanceMode); }
    if (els.dynamicBackgroundToggle) els.dynamicBackgroundToggle.checked = Boolean(state.dynamicBackgroundEnabled);
    if (els.startupAnimationToggle) els.startupAnimationToggle.checked = Boolean(state.startupAnimationEnabled);
    els.crossfadeToggle.checked = Boolean(state.crossfadeEnabled); els.crossfadeSeconds.value = String(state.crossfadeSeconds); $('#crossfadeSecondsValue').textContent = `${state.crossfadeSeconds} s`;
    els.gaplessToggle.checked = Boolean(state.gaplessEnabled); els.replayGainToggle.checked = Boolean(state.replayGainEnabled); els.limiterToggle.checked = Boolean(state.finalLimiterEnabled);
    els.fadeInToggle.checked = Boolean(state.fadeInEnabled); els.fadeInSeconds.value = String(state.fadeInSeconds); $('#fadeInSecondsValue').textContent = `${Number(state.fadeInSeconds).toFixed(1)} s`;
    els.fadeOutToggle.checked = Boolean(state.fadeOutEnabled); els.fadeOutSeconds.value = String(state.fadeOutSeconds); $('#fadeOutSecondsValue').textContent = `${Number(state.fadeOutSeconds).toFixed(1)} s`;
  }
  function applyReplayGain(){const song=songById(state.currentId);if(!song)return;const db=Number(song.replayGainTrackDb);if(Number.isFinite(db)&&masterGain){masterGain.gain.value=state.volume*Math.pow(10,db/20)*getSafeHeadroom();}else if(masterGain){masterGain.gain.value=state.volume*getSafeHeadroom();}}

  function applyPerformanceMode() {
    if (state.performanceMode) {
      // Performance mode is a real low-effects profile: disable all three expensive UI effects.
      state.glassEnabled = false;
      state.transparencyEnabled = false;
      state.animationsEnabled = false;
    }
    document.body.classList.toggle('performance-mode', Boolean(state.performanceMode));
    if (els.performanceModeToggle) els.performanceModeToggle.checked = Boolean(state.performanceMode);
    applyUiEffects();
    syncPlaybackSettingsUI();
  }

  function applyUiEffects() {
    document.body.classList.toggle('ui-glass-disabled', !state.glassEnabled);
    document.body.classList.toggle('ui-transparency-disabled', !state.transparencyEnabled);
    document.body.classList.toggle('ui-animations-disabled', !state.animationsEnabled);
    document.body.classList.toggle('ui-dynamic-background-disabled', !state.dynamicBackgroundEnabled);
    if (els.glassEffectToggle) els.glassEffectToggle.checked = Boolean(state.glassEnabled);
    if (els.transparencyToggle) els.transparencyToggle.checked = Boolean(state.transparencyEnabled);
    if (els.animationsToggle) els.animationsToggle.checked = Boolean(state.animationsEnabled);
    if (els.dynamicBackgroundToggle) els.dynamicBackgroundToggle.checked = Boolean(state.dynamicBackgroundEnabled);
    if (els.startupAnimationToggle) els.startupAnimationToggle.checked = Boolean(state.startupAnimationEnabled);
    const song = songById(state.currentId);
    if (song) updateBackground(song);
    else if (state.onlineCurrentTrack) updateOnlineBackground(state.onlineCurrentTrack);
    else document.documentElement.style.removeProperty('--bg-image');
  }
  const JAMENDO_API='https://api.jamendo.com/v3.0/tracks/';
  function updateOnlineStatus(){if(!els.onlineStatus)return;if(state.jamendoClientId){els.onlineStatus.textContent='Online conectado';els.onlineStatus.classList.add('online-ok');}else{els.onlineStatus.textContent='Online desconectado';els.onlineStatus.classList.remove('online-ok');}}

  function readStoredGoogleProfile() {
    try {
      const value = JSON.parse(localStorage.getItem('auro-google-profile-v1') || 'null');
      return value && typeof value === 'object' && value.email ? value : null;
    } catch { return null; }
  }
  function storeGoogleProfile(profile) {
    state.googleAccount = profile && profile.email ? {
      id: String(profile.id || ''), email: String(profile.email), name: String(profile.name || profile.email),
      picture: String(profile.picture || ''), verified: profile.verified === true, associatedAt: Date.now(),
    } : null;
    try {
      if (state.googleAccount) localStorage.setItem('auro-google-profile-v1', JSON.stringify(state.googleAccount));
      else localStorage.removeItem('auro-google-profile-v1');
    } catch {}
    syncGoogleAccountUI();
    persistState();
  }
  function syncGoogleAccountUI() {
    const profile = (state.googleAccount && state.googleAccount.email) ? state.googleAccount : readStoredGoogleProfile();
    if (profile) state.googleAccount = profile;
    if (els.googleAccountStatus) {
      els.googleAccountStatus.textContent = profile
        ? `Cuenta asociada en este equipo: ${profile.email}. ẞetaMusic no guarda el token de acceso ni sincroniza esta identidad con un servidor.`
        : 'Opcional. La cuenta solo se asocia localmente en este equipo; aún no hay sincronización ni contador global.';
    }
    if (els.googleAccountBtn) els.googleAccountBtn.textContent = profile ? 'Quitar cuenta' : 'Conectar con Google';
  }
  async function runGoogleSignIn(statusElement, buttonElement) {
    if (buttonElement) { buttonElement.disabled = true; buttonElement.dataset.originalText = buttonElement.textContent; buttonElement.textContent = 'Conectando…'; }
    if (statusElement) { statusElement.classList.remove('is-error','is-success'); statusElement.textContent = 'Comprobando la configuración de Google…'; }
    try {
      const status = await window.auroAuth?.getStatus?.();
      if (!status?.configured) {
        const message = `La autenticación está preparada, pero falta el Client ID de Google. Archivo de configuración: ${status?.configPath || 'google-auth-config.json'}. Puedes continuar sin cuenta y activarla más adelante.`;
        if (statusElement) { statusElement.classList.add('is-error'); statusElement.textContent = message; }
        else showToast(`Falta configurar el Client ID de Google. Archivo: ${status?.configPath || 'google-auth-config.json'}`);
        return false;
      }
      if (statusElement) statusElement.textContent = 'Se abrirá el navegador predeterminado para iniciar sesión con Google…';
      const response = await window.auroAuth.signInWithGoogle();
      if (!response?.ok) {
        const message = response?.reason === 'not-configured'
          ? 'Falta configurar las credenciales de Google.'
          : (response?.message || 'No se pudo completar el inicio de sesión.');
        if (statusElement) { statusElement.classList.add('is-error'); statusElement.textContent = message; }
        else showToast(message);
        return false;
      }
      storeGoogleProfile(response.profile);
      if (buttonElement === onboarding.signInBtn && onboarding.continueBtn) onboarding.continueBtn.textContent = 'Continuar a la configuración →';
      if (statusElement) { statusElement.classList.remove('is-error'); statusElement.classList.add('is-success'); statusElement.textContent = `Google verificó la cuenta ${response.profile.email}. El perfil se guarda solo en este equipo.`; }
      showToast(`Cuenta de Google verificada: ${response.profile.email}`);
      return true;
    } catch (error) {
      const message = `No se pudo iniciar sesión: ${error?.message || error}`;
      if (statusElement) { statusElement.classList.add('is-error'); statusElement.textContent = message; }
      else showToast(message);
      return false;
    } finally {
      if (buttonElement) { buttonElement.disabled = false; buttonElement.textContent = buttonElement.dataset.originalText || 'Continuar'; delete buttonElement.dataset.originalText; }
    }
  }
  async function handleGoogleAccountButton() {
    if (state.googleAccount || readStoredGoogleProfile()) {
      storeGoogleProfile(null);
      showToast('Se quitó la asociación local de Google. No se cerró la sesión del navegador.');
      return;
    }
    const ok = await runGoogleSignIn(null, els.googleAccountBtn);
    if (ok) showToast('Cuenta asociada localmente a ẞetaMusic.');
  }

  const onboarding = {
    overlay: document.getElementById('welcomeOverlay'),
    accountStep: document.getElementById('welcomeAccountStep'),
    profileStep: document.getElementById('welcomeProfileStep'),
    stepLabel: document.getElementById('welcomeStepLabel'),
    authStatus: document.getElementById('welcomeAuthStatus'),
    signInBtn: document.getElementById('googleSignInBtn'),
    continueBtn: document.getElementById('continueWithoutAccountBtn'),
    backBtn: document.getElementById('backToAccountBtn'),
    finishBtn: document.getElementById('finishWelcomeBtn'),
    hardwareSummary: document.getElementById('hardwareSummary'),
    customOptions: document.getElementById('customProfileOptions'),
  };
  let selectedWelcomeProfile = 'balanced';
  let hardwareInfo = null;
  let welcomeScheduled = false;

  function queueWelcomeExperience() {
    if (welcomeScheduled || !onboarding.overlay) return;
    welcomeScheduled = true;
    let alreadyCompleted = false;
    try { alreadyCompleted = localStorage.getItem('auro-onboarding-complete-v1') === 'true'; } catch {}
    if (state.onboardingComplete || alreadyCompleted) return;
    const wait = state.startupAnimationEnabled ? 1850 : 80;
    setTimeout(() => {
      let completed = false;
      try { completed = localStorage.getItem('auro-onboarding-complete-v1') === 'true'; } catch {}
      if (!completed && !state.onboardingComplete) openWelcomeExperience();
    }, wait);
  }
  async function openWelcomeExperience() {
    if (!onboarding.overlay) return;
    onboarding.continueBtn.disabled = true;
    onboarding.overlay.classList.add('open');
    onboarding.overlay.setAttribute('aria-hidden','false');
    onboarding.accountStep.hidden = false;
    onboarding.profileStep.hidden = true;
    onboarding.stepLabel.textContent = 'BIENVENIDA · 1 DE 2';
    const stored = state.googleAccount || readStoredGoogleProfile();
    if (stored && onboarding.authStatus) {
      onboarding.continueBtn.textContent = 'Continuar a la configuración →';
      onboarding.authStatus.classList.remove('is-error');
      onboarding.authStatus.classList.add('is-success');
      onboarding.authStatus.textContent = `En este equipo ya está asociada la cuenta ${stored.email}. Puedes continuar o volver a conectarte con Google.`;
    } else {
      onboarding.continueBtn.textContent = 'Continuar sin cuenta →';
    }
    try {
      const status = await window.auroAuth?.getStatus?.();
      if (status?.configured) {
        if (onboarding.authStatus && !stored) onboarding.authStatus.textContent = 'Google está configurado. El acceso se abrirá de forma segura en tu navegador.';
      } else if (onboarding.authStatus && !stored) {
        onboarding.authStatus.textContent = `Inicio de sesión preparado; falta el Client ID de Google. Archivo: ${status?.configPath || 'google-auth-config.json'}. Puedes seguir sin cuenta.`;
      }
    } catch {}
    try {
      hardwareInfo = await window.auroAuth?.getSystemInfo?.();
    } catch { hardwareInfo = null; }
    const recommendation = hardwareInfo?.recommendedProfile || 'balanced';
    selectedWelcomeProfile = recommendation;
    if (onboarding.hardwareSummary) {
      onboarding.hardwareSummary.textContent = hardwareInfo
        ? `Equipo detectado: ${hardwareInfo.ramGb} GB de RAM, ${hardwareInfo.logicalThreads} hilos lógicos y ${hardwareInfo.gpuDescription || 'GPU no identificada'} (${hardwareInfo.cpuModel}). Perfil sugerido: ${profileTitle(recommendation)}. Puedes elegir cualquier otro.`
        : 'No se pudo consultar todo el hardware. Elige el perfil que prefieras; puedes cambiarlo luego en Configuración.';
    }
    syncWelcomeProfileCards();
    fillCustomProfileInputsFromState();
    onboarding.continueBtn.disabled = false;
  }
  function profileTitle(profile) { return ({high:'Visual premium',balanced:'Equilibrado',low:'Bajo consumo',custom:'Personalizado'})[profile] || 'Equilibrado'; }
  function syncWelcomeProfileCards() {
    document.querySelectorAll('.profile-card[data-profile]').forEach(card => card.setAttribute('aria-pressed', String(card.dataset.profile === selectedWelcomeProfile)));
    if (onboarding.customOptions) onboarding.customOptions.hidden = selectedWelcomeProfile !== 'custom';
  }
  function fillCustomProfileInputsFromState() {
    const controls = {
      customGlass: state.glassEnabled,
      customTransparency: state.transparencyEnabled,
      customAnimations: state.animationsEnabled,
      customDynamicBackground: state.dynamicBackgroundEnabled,
      customStartupAnimation: state.startupAnimationEnabled,
    };
    for (const [id,value] of Object.entries(controls)) {
      const control = document.getElementById(id);
      if (control) control.checked = Boolean(value);
    }
  }
  function showWelcomeProfileStep() {
    onboarding.accountStep.hidden = true;
    onboarding.profileStep.hidden = false;
    onboarding.stepLabel.textContent = 'CONFIGURACIÓN · 2 DE 2';
    syncWelcomeProfileCards();
    fillCustomProfileInputsFromState();
  }
  function returnToWelcomeAccountStep() {
    onboarding.profileStep.hidden = true;
    onboarding.accountStep.hidden = false;
    onboarding.stepLabel.textContent = 'BIENVENIDA · 1 DE 2';
  }
  function applyWelcomeProfile(profile) {
    state.performanceProfile = profile;
    if (profile === 'high') {
      Object.assign(state,{performanceMode:false,performanceRestore:null,glassEnabled:true,transparencyEnabled:true,animationsEnabled:true,dynamicBackgroundEnabled:true,startupAnimationEnabled:true});
    } else if (profile === 'balanced') {
      Object.assign(state,{performanceMode:false,performanceRestore:null,glassEnabled:false,transparencyEnabled:true,animationsEnabled:true,dynamicBackgroundEnabled:false,startupAnimationEnabled:true});
    } else if (profile === 'low') {
      Object.assign(state,{performanceMode:true,performanceRestore:{glassEnabled:false,transparencyEnabled:false,animationsEnabled:false},glassEnabled:false,transparencyEnabled:false,animationsEnabled:false,dynamicBackgroundEnabled:false,startupAnimationEnabled:false});
    } else {
      const get = id => Boolean(document.getElementById(id)?.checked);
      const glassEnabled = get('customGlass');
      const transparencyEnabled = get('customTransparency');
      const animationsEnabled = get('customAnimations');
      Object.assign(state,{performanceMode:false,performanceRestore:null,glassEnabled,transparencyEnabled,animationsEnabled,dynamicBackgroundEnabled:get('customDynamicBackground'),startupAnimationEnabled:get('customStartupAnimation')});
    }
    document.documentElement.classList.toggle('startup-animation-off', !state.startupAnimationEnabled);
    try { localStorage.setItem('auro-startup-animation-enabled',String(state.startupAnimationEnabled)); } catch {}
    applyPerformanceMode();
    applyUiEffects();
    syncPlaybackSettingsUI();
    persistState({performanceProfile:state.performanceProfile});
  }
  function finishWelcomeExperience() {
    applyWelcomeProfile(selectedWelcomeProfile);
    state.onboardingComplete = true;
    try { localStorage.setItem('auro-onboarding-complete-v1','true'); } catch {}
    persistState({onboardingComplete:true,performanceProfile:state.performanceProfile,googleAccount:state.googleAccount});
    onboarding.overlay.classList.remove('open');
    onboarding.overlay.setAttribute('aria-hidden','true');
    setTimeout(() => { onboarding.overlay?.remove(); }, 450);
    showToast(`Configuración aplicada: ${profileTitle(selectedWelcomeProfile)}.`);
  }
  onboarding.signInBtn?.addEventListener('click', async () => {
    const ok = await runGoogleSignIn(onboarding.authStatus,onboarding.signInBtn);
    if (ok) {
      onboarding.authStatus?.classList.add('is-success');
      syncGoogleAccountUI();
    }
  });
  onboarding.continueBtn?.addEventListener('click', showWelcomeProfileStep);
  onboarding.backBtn?.addEventListener('click', returnToWelcomeAccountStep);
  onboarding.finishBtn?.addEventListener('click', finishWelcomeExperience);
  document.querySelectorAll('.profile-card[data-profile]').forEach(card => card.addEventListener('click', () => {
    selectedWelcomeProfile = card.dataset.profile;
    syncWelcomeProfileCards();
  }));

  function openOnlineSettings(){if(!els.onlineSettingsOverlay)return;els.jamendoClientIdInput.value=state.jamendoClientId||'';els.onlineSettingsOverlay.classList.add('open');els.onlineSettingsOverlay.setAttribute('aria-hidden','false');setTimeout(()=>els.jamendoClientIdInput.focus(),50);}
  function closeOnlineSettings(){if(!els.onlineSettingsOverlay)return;els.onlineSettingsOverlay.classList.remove('open');els.onlineSettingsOverlay.setAttribute('aria-hidden','true');}
  function saveOnlineSettings(){state.jamendoClientId=String(els.jamendoClientIdInput.value||'').trim();persistState();updateOnlineStatus();closeOnlineSettings();if(state.jamendoClientId){showToast('ẞeta Online conectado.');if(state.view==='online')searchOnline(state.query||'');}else showToast('Client ID vacío.');}
  function disconnectOnline(){state.jamendoClientId='';state.onlineResults=[];state.onlineCurrentTrack=null;state.onlineCurrentIndex=-1;persistState();updateOnlineStatus();closeOnlineSettings();if(state.view==='online')renderOnlineHome();showToast('ẞeta Online desconectado.');}
  function onlineTrackCard(t,i){const fav=state.onlineFavorites.includes(String(t.id));const cover=t.album_image||t.image||'';return `<div class="online-track" data-online-index="${i}"><img class="online-cover" src="${escapeAttr(cover)}" alt=""><div class="online-track-info"><strong>${escapeHTML(t.name||'Sin título')}</strong><span>${escapeHTML(t.artist_name||'Artista desconocido')}</span><small>${escapeHTML(t.album_name||'Single')} · ${formatTime(Number(t.duration)||0)}</small></div><button class="online-fav ${fav?'active':''}" data-online-fav="${escapeAttr(t.id)}" title="Favorito">${fav?'♥':'♡'}</button><button class="online-play" data-online-play="${i}" title="Reproducir">▶</button></div>`;}
  function renderOnlineHome(){els.sectionTitle.textContent='ẞeta Online';els.viewDescription.textContent=state.jamendoClientId?'Catálogo online · música independiente':'Conecta un catálogo para comenzar';if(els.newPlaylistBtn) els.newPlaylistBtn.style.display='none';if(!state.jamendoClientId){els.libraryBody.innerHTML=`<div class="online-empty"><div class="online-empty-icon">◉</div><h3>Escucha música online</h3><p>Conecta tu Client ID para buscar y reproducir música del catálogo compatible con ẞetaMusic.</p><button class="primary-btn" id="onlineEmptyConnect">⚙ Conectar catálogo</button><small>Fuente: Jamendo · ẞetaMusic no descarga ni almacena las pistas online.</small></div>`;document.getElementById('onlineEmptyConnect')?.addEventListener('click',openOnlineSettings);return;}if(state.onlineLoading){els.libraryBody.innerHTML='<div class="online-empty"><div class="online-spinner">◌</div><h3>Buscando música…</h3><p>Consultando el catálogo online.</p></div>';return;}if(!state.onlineResults.length){els.libraryBody.innerHTML=`<div class="online-empty"><div class="online-empty-icon">♫</div><h3>Descubre música</h3><p>Busca una canción, artista, género o estado de ánimo en la barra superior.</p><div class="online-chips"><button data-online-query="electronic">Electronic</button><button data-online-query="rock">Rock</button><button data-online-query="jazz">Jazz</button><button data-online-query="chill">Chill</button><button data-online-query="pop">Pop</button></div></div>`;bindOnlineDynamic();return;}els.libraryBody.innerHTML=`<div class="online-head"><div><span class="eyebrow">CATÁLOGO ONLINE</span><h3>${state.query?`Resultados para “${escapeHTML(state.query)}”`:'Descubrir'}</h3></div><span class="online-count">${state.onlineResults.length} pistas · Jamendo</span></div><div class="online-list">${state.onlineResults.map(onlineTrackCard).join('')}</div>`;bindOnlineDynamic();}
  function bindOnlineDynamic(){els.libraryBody.querySelectorAll('[data-online-play]').forEach(b=>b.addEventListener('click',e=>{e.stopPropagation();playOnlineIndex(Number(b.dataset.onlinePlay));}));els.libraryBody.querySelectorAll('[data-online-index]').forEach(r=>r.addEventListener('dblclick',()=>playOnlineIndex(Number(r.dataset.onlineIndex))));els.libraryBody.querySelectorAll('[data-online-fav]').forEach(b=>b.addEventListener('click',e=>{e.stopPropagation();toggleOnlineFavorite(String(b.dataset.onlineFav));}));els.libraryBody.querySelectorAll('[data-online-query]').forEach(b=>b.addEventListener('click',()=>{state.query=normalizeText(b.dataset.onlineQuery);els.librarySearch.value=b.dataset.onlineQuery;searchOnline(state.query);}));}
  async function searchOnline(query=''){if(state.view!=='online')return;if(!state.jamendoClientId){renderOnlineHome();return;}state.onlineLoading=true;renderOnlineHome();try{const u=new URL(JAMENDO_API);u.searchParams.set('client_id',state.jamendoClientId);u.searchParams.set('format','json');u.searchParams.set('limit','40');u.searchParams.set('audioformat','mp32');u.searchParams.set('imagesize','200');u.searchParams.set('type','single albumtrack');if(query)u.searchParams.set('search',query);else{u.searchParams.set('featured','1');u.searchParams.set('order','popularity_week');}const data=window.auroOnline?.fetchJson ? await window.auroOnline.fetchJson(u.toString()) : await (await fetch(u.toString())).json();if(data?.headers?.status!=='success')throw new Error(data?.headers?.error_message||'La API rechazó la solicitud.');state.onlineResults=(data.results||[]).filter(t=>t.audio);state.onlineLoading=false;renderOnlineHome();if(!state.onlineResults.length)showToast('No se encontraron pistas.');}catch(e){console.error(e);state.onlineResults=[];state.onlineLoading=false;renderOnlineHome();showToast('No se pudo conectar con el catálogo online. Revisa Internet y el Client ID.');}}
  function toggleOnlineFavorite(id){const i=state.onlineFavorites.indexOf(id);if(i>=0)state.onlineFavorites.splice(i,1);else state.onlineFavorites.push(id);persistState();renderOnlineHome();}
  async function playOnlineIndex(index){const track=state.onlineResults[index];if(!track)return;state.onlineCurrentTrack=track;state.onlineCurrentIndex=index;state.currentId=null;state.resumeTime=0;state.queueIds=[];state.queueIndex=-1;releaseAudioUrl();els.audio.src=track.audio;els.audio.load();updateNowPlaying();renderQueue();try{await ensureAudioGraph();await resumeContext();await els.audio.play();}catch(e){try{await els.audio.play();}catch(err){console.error(err);showToast('No se pudo reproducir la pista online.');}}}
  async function playNextOnline(){if(!state.onlineResults.length)return;let i=state.onlineCurrentIndex+1;if(i>=state.onlineResults.length)i=0;await playOnlineIndex(i);}
  async function playPreviousOnline(){if(els.audio.currentTime>3){els.audio.currentTime=0;return;}let i=state.onlineCurrentIndex-1;if(i<0)i=state.onlineResults.length-1;await playOnlineIndex(i);}
  function formatTime(v){if(!Number.isFinite(v))return'0:00';const t=Math.max(0,Math.floor(v)),m=Math.floor(t/60),s=t%60;return `${m}:${String(s).padStart(2,'0')}`;} function formatBytes(v){if(!v)return'0 B';const u=['B','KB','MB','GB'],i=Math.min(u.length-1,Math.floor(Math.log(v)/Math.log(1024)));return `${(v/1024**i).toFixed(i?1:0)} ${u[i]}`;} function inferMime(n){const e=extensionOf(n).toLowerCase();return({mp3:'audio/mpeg',m4a:'audio/mp4',flac:'audio/flac',ogg:'audio/ogg',wav:'audio/wav',aac:'audio/aac',webm:'audio/webm'})[e]||'audio/*';} function extensionOf(n){return String(n).split('.').pop()||'';} function cleanText(v){return Array.isArray(v)?v.join(', '):String(v||'').trim();} function normalizeText(v){return String(v||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLocaleLowerCase().trim();} function clamp(v,min,max){return Math.min(max,Math.max(min,v));} function smartShuffledIds(ids){const pool=[...ids];const result=[];while(pool.length){let total=0;const weights=pool.map(id=>{const s=songById(id);const plays=s?.playCount||0;const recent=s?.lastPlayed||0;const age=recent?Math.max(0,1-(Date.now()-recent)/604800000):1;const w=1/(1+plays*0.8+age*0.7);total+=w;return w;});let r=Math.random()*total,chosen=pool.length-1;for(let i=0;i<pool.length;i++){r-=weights[i];if(r<=0){chosen=i;break;}}result.push(pool.splice(chosen,1)[0]);}return result;} function shuffledIds(ids){const a=[...ids];for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;} function songById(id){return state.library.find(s=>s.id===id)||null;} function hashString(t){let h=2166136261;for(let i=0;i<t.length;i++)h=Math.imul(h^t.charCodeAt(i),16777619);return(h>>>0).toString(36);} function escapeHTML(v){return String(v).replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));} function escapeAttr(v){return escapeHTML(v);} function showToast(m){clearTimeout(toastTimer);els.toast.textContent=m;els.toast.classList.add('show');toastTimer=setTimeout(()=>els.toast.classList.remove('show'),1900);}
  els.libraryBody.addEventListener('click',(event)=>{if(event.target.id==='emptyAddBtn')els.filePicker.click();});
  els.audio.addEventListener('play',()=>{const song=songById(state.currentId);if(song&&lastCountedPlayId!==song.id){lastCountedPlayId=song.id;recordPlay(song.id);}});
  els.audio.addEventListener('pause',()=>{const song=!state.onlineCurrentTrack&&songById(state.currentId);if(song&&db)idbRequest(tx(SONG_STORE,'readwrite').put(song)).catch(console.error);lastListenPosition=Number(els.audio.currentTime)||0;});
})();
