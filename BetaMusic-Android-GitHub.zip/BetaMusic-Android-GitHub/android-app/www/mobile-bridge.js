/* Adaptadores explícitos para el WebView de Android.
   No simula un inicio de sesión de Google: esa función queda deshabilitada
   hasta integrar un flujo OAuth nativo real. */
(() => {
  'use strict';

  const allowedHosts = new Set(['api.jamendo.com', 'lrclib.net']);
  const originalFetch = window.fetch.bind(window);

  window.auroOnline = window.auroOnline || {};
  window.auroOnline.fetchJson = async (rawUrl) => {
    const url = new URL(String(rawUrl));
    if (url.protocol !== 'https:' || !allowedHosts.has(url.hostname)) {
      throw new Error('Destino online no permitido.');
    }
    const allowedPath = url.hostname === 'api.jamendo.com'
      ? url.pathname.startsWith('/v3.0/tracks/')
      : url.pathname.startsWith('/api/');
    if (!allowedPath) throw new Error('Ruta online no permitida.');

    const response = await originalFetch(url.toString(), {
      method: 'GET',
      headers: { 'Accept': 'application/json' },
      cache: 'no-store'
    });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    return response.json();
  };

  window.auroAuth = {
    async getStatus() {
      return {
        configured: false,
        configPath: 'Inicio de sesión Google nativo aún no integrado en Android'
      };
    },
    async signInWithGoogle() {
      return {
        ok: false,
        reason: 'android-not-supported',
        message: 'El inicio de sesión con Google todavía no está integrado en esta versión Android.'
      };
    },
    async getSystemInfo() {
      return null;
    }
  };
})();
