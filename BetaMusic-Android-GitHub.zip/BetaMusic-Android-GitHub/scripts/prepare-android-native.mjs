import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const scriptDir = path.dirname(fileURLToPath(import.meta.url));
const projectRoot = path.resolve(scriptDir, '..');
const androidRoot = path.resolve(process.argv[2] || path.join(projectRoot, 'android-app', 'android'));
const assetsRoot = path.join(projectRoot, 'android-assets', 'res');
const destinationRes = path.join(androidRoot, 'app', 'src', 'main', 'res');

if (!fs.existsSync(path.join(androidRoot, 'app', 'src', 'main', 'AndroidManifest.xml'))) {
  console.error(`No se encontró el proyecto Android generado en: ${androidRoot}`);
  process.exit(1);
}
if (!fs.existsSync(assetsRoot)) {
  console.error(`No se encontraron los iconos Android incluidos en: ${assetsRoot}`);
  process.exit(1);
}

function copyDirectoryContents(source, destination) {
  if (!fs.existsSync(source)) return;
  fs.mkdirSync(destination, { recursive: true });
  for (const item of fs.readdirSync(source, { withFileTypes: true })) {
    const from = path.join(source, item.name);
    const to = path.join(destination, item.name);
    if (item.isDirectory()) copyDirectoryContents(from, to);
    else fs.copyFileSync(from, to);
  }
}

copyDirectoryContents(assetsRoot, destinationRes);

const valuesDir = path.join(destinationRes, 'values');
const colorsFile = path.join(valuesDir, 'colors.xml');
fs.mkdirSync(valuesDir, { recursive: true });
let colors = fs.existsSync(colorsFile)
  ? fs.readFileSync(colorsFile, 'utf8')
  : '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n</resources>\n';
if (/name="ic_launcher_background"/.test(colors)) {
  colors = colors.replace(/<color\s+name="ic_launcher_background"[^>]*>.*?<\/color>/s, '    <color name="ic_launcher_background">#080A12</color>');
} else {
  colors = colors.replace('</resources>', '    <color name="ic_launcher_background">#080A12</color>\n</resources>');
}
fs.writeFileSync(colorsFile, colors, 'utf8');

const manifestPath = path.join(androidRoot, 'app', 'src', 'main', 'AndroidManifest.xml');
const manifest = fs.readFileSync(manifestPath, 'utf8');
if (!manifest.includes('@mipmap/ic_launcher')) {
  console.warn('Aviso: el AndroidManifest.xml no referencia @mipmap/ic_launcher; revisa el icono del lanzador.');
}
console.log('Iconos ẞetaMusic copiados al proyecto Android.');
